/** @type {import('tailwindcss').Config} */
import typography from '@tailwindcss/typography';

export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        'coral': '#FF7F50',
        'primary': {
          DEFAULT: '#FF7F50',
          dark: '#FF6347',
          light: '#FFA07A'
        },
        'secondary': {
          DEFAULT: '#FFD700',
          dark: '#FFC72C',
          light: '#FFE55C'
        },
        'accent': {
          DEFAULT: '#32CD32',
          dark: '#228B22',
          light: '#90EE90'
        },
        'neutral': {
          50: '#F8F9FA',
          100: '#F1F3F5',
          200: '#E9ECEF',
          300: '#DEE2E6',
          400: '#CED4DA',
          500: '#ADB5BD',
          600: '#6C757D',
          700: '#495057',
          800: '#343A40',
          900: '#212529'
        }
      },
      fontFamily: {
        sans: ['Roboto', 'system-ui', 'sans-serif'],
        serif: ['Playfair Display', 'serif'],
        display: ['Poppins', 'system-ui', 'sans-serif']
      },
      dropShadow: {
        'glow': '0 0 10px rgba(255, 127, 80, 0.3)',
      },
      animation: {
        'float': 'float 3s ease-in-out infinite',
      },
      keyframes: {
        float: {
          '0%, 100%': { transform: 'translateY(0)' },
          '50%': { transform: 'translateY(-10px)' },
        }
      }
    },
  },
  plugins: [typography],
};