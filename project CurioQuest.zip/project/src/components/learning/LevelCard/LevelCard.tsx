import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Book, Brain, GamepadIcon, Trophy, CheckCircle } from 'lucide-react';
import { generateLearningContent } from '../../../services/ai/generators';
import { LoadingSpinner } from '../../common/LoadingSpinner/LoadingSpinner';
import './LevelCard.css';

interface LevelCardProps {
  topic: string;
  ageRange: string;
  description: string;
  type?: 'lesson' | 'quiz' | 'game' | 'challenge' | 'reward';
  isCompleted?: boolean;
  isLocked?: boolean;
  onComplete: (topic: string) => void;
}

export function LevelCard({
  topic,
  ageRange,
  description,
  type = 'lesson',
  isCompleted = false,
  isLocked = false,
  onComplete
}: LevelCardProps) {
  const [isLoading, setIsLoading] = useState(false);
  const [content, setContent] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const getIcon = () => {
    switch (type) {
      case 'quiz':
        return <Brain className="h-6 w-6" />;
      case 'game':
        return <GamepadIcon className="h-6 w-6" />;
      case 'challenge':
        return <Trophy className="h-6 w-6" />;
      default:
        return <Book className="h-6 w-6" />;
    }
  };

  const getButtonText = () => {
    switch (type) {
      case 'quiz':
        return 'Start Quiz';
      case 'game':
        return 'Start Game';
      case 'challenge':
        return 'Start Challenge';
      default:
        return 'Start Lesson';
    }
  };

  const handleStart = async () => {
    if (isLocked) return;
    
    setIsLoading(true);
    setError(null);
    
    try {
      const response = await generateLearningContent(
        `Create an engaging ${type} about ${topic} for children aged ${ageRange}`,
        {
          complexity: parseInt(ageRange.split('-')[0]) / 3,
          responseType: 'text',
          responseLength: 'medium'
        }
      );
      setContent(response.content);
    } catch (err) {
      setError(err instanceof Error ? err.message : `Failed to generate ${type}`);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className={`level-card ${isLocked ? 'locked' : ''} ${isCompleted ? 'completed' : ''} ${type}`}
    >
      <div className="card-header">
        <div className={`icon-wrapper ${type}`}>
          {getIcon()}
        </div>
        <div className="flex-1">
          <h3 className="card-title">{topic}</h3>
          <p className="card-age">Ages {ageRange}</p>
        </div>
        {isCompleted && (
          <CheckCircle className="h-6 w-6 text-green-500" />
        )}
      </div>

      <p className="card-description">{description}</p>

      {error && (
        <div className="error-message">
          {error}
        </div>
      )}

      <div className="button-container">
        {content ? (
          <div className="lesson-content">
            <div className="prose prose-sm">{content}</div>
            <button
              onClick={() => onComplete(topic)}
              className="complete-button"
            >
              Complete {type}
            </button>
          </div>
        ) : (
          <button
            onClick={handleStart}
            disabled={isLocked || isLoading}
            className={`start-button ${type}`}
          >
            {isLoading ? (
              <LoadingSpinner size="sm" />
            ) : isLocked ? (
              'Locked'
            ) : (
              getButtonText()
            )}
          </button>
        )}
      </div>
    </motion.div>
  );
}