import React from 'react';
import { motion } from 'framer-motion';
import { Topic } from '../../../data/mathematics/types';

interface TopicCardProps {
  topic: Topic;
  onClick: () => void;
}

export function TopicCard({ topic, onClick }: TopicCardProps) {
  const totalLessons = topic.subtopics.reduce(
    (acc, subtopic) => acc + subtopic.lessons.length,
    0
  );

  return (
    <motion.button
      onClick={onClick}
      className="w-full p-6 bg-white rounded-xl shadow-lg hover:shadow-xl transition-all"
      whileHover={{ scale: 1.02 }}
      whileTap={{ scale: 0.98 }}
    >
      <h3 className="text-xl font-bold mb-2">{topic.title}</h3>
      <p className="text-neutral-600">
        {totalLessons} {totalLessons === 1 ? 'Lesson' : 'Lessons'} • {topic.subtopics.length} {topic.subtopics.length === 1 ? 'Subtopic' : 'Subtopics'}
      </p>
    </motion.button>
  );
}