import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { ArrowLeft, BookOpen, Brain, Gamepad } from 'lucide-react';
import { mathematicsCurriculum, KeyStage } from '../../../data/mathematics/curriculum';
import { LevelCard } from '../LevelCard/LevelCard';
import { useAuth } from '../../../features/auth/hooks/useAuth';
import { updateUserProgress } from '../../../services/learning/progressService';

export function MathematicsHub() {
    const { user } = useAuth();
    const [selectedKeyStage, setSelectedKeyStage] = useState<KeyStage | null>(null);
    const [selectedTopic, setSelectedTopic] = useState<string | null>(null);
    const [selectedSubtopic, setSelectedSubtopic] = useState<string | null>(null);
    const [selectedType, setSelectedType] = useState<'lesson' | 'quiz' | 'game' | null>(null);

    const handleComplete = async (activityId: string) => {
        if (!user?.uid) return;
        await updateUserProgress(user.uid, activityId);
    };

    const countActivityTypes = (activities: any[]) => {
        return activities.reduce((counts, activity) => {
            const type = activity.type || 'lesson';
            counts[type] = (counts[type] || 0) + 1;
            return counts;
        }, {} as Record<string, number>);
    };

    const renderKeyStages = () => {
        return (
            <div className="grid gap-6 md:grid-cols-2">
                {(Object.keys(mathematicsCurriculum) as KeyStage[]).map((keyStage, index) => (
                    <motion.button
                        key={keyStage}
                        onClick={() => setSelectedKeyStage(keyStage)}
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: index * 0.1 }}
                        className="p-8 bg-primary/10 rounded-xl shadow-lg transition-all text-left hover:bg-primary/20"
                    >
                        <h2 className="text-2xl font-bold mb-2">
                            {mathematicsCurriculum[keyStage].title}
                        </h2>
                        <p className="text-neutral-600 mb-2">
                            {mathematicsCurriculum[keyStage].topics.length} Topics
                        </p>
                        <p className="text-sm text-neutral-500">
                            Click to explore {mathematicsCurriculum[keyStage].title} mathematics
                        </p>
                    </motion.button>
                ))}
            </div>
        );
    };

    const renderActivities = () => {
        if (!selectedKeyStage || !selectedTopic || !selectedSubtopic) return null;
        
        const topic = mathematicsCurriculum[selectedKeyStage].topics
            .find(t => t.id === selectedTopic);
        const subtopic = topic?.subtopics.find(s => s.id === selectedSubtopic);
        
        if (!subtopic) return null;

        const activities = 'activities' in subtopic ? subtopic.activities : 
                         'lessons' in subtopic ? subtopic.lessons : [];

        const filteredActivities = selectedType 
            ? activities.filter(activity => (activity.type || 'lesson') === selectedType)
            : activities;

        return (
            <>
                <div className="flex gap-4 mb-6">
                    <button
                        onClick={() => setSelectedType(null)}
                        className={`px-4 py-2 rounded-lg transition-colors ${!selectedType ? 'bg-primary text-white' : 'bg-gray-100 hover:bg-gray-200'}`}
                    >
                        All
                    </button>
                    <button
                        onClick={() => setSelectedType('lesson')}
                        className={`px-4 py-2 rounded-lg transition-colors flex items-center gap-2 ${selectedType === 'lesson' ? 'bg-primary text-white' : 'bg-gray-100 hover:bg-gray-200'}`}
                    >
                        <BookOpen className="w-4 h-4" />
                        Lessons
                    </button>
                    <button
                        onClick={() => setSelectedType('quiz')}
                        className={`px-4 py-2 rounded-lg transition-colors flex items-center gap-2 ${selectedType === 'quiz' ? 'bg-primary text-white' : 'bg-gray-100 hover:bg-gray-200'}`}
                    >
                        <Brain className="w-4 h-4" />
                        Quizzes
                    </button>
                    <button
                        onClick={() => setSelectedType('game')}
                        className={`px-4 py-2 rounded-lg transition-colors flex items-center gap-2 ${selectedType === 'game' ? 'bg-primary text-white' : 'bg-gray-100 hover:bg-gray-200'}`}
                    >
                        <Gamepad className="w-4 h-4" />
                        Games
                    </button>
                </div>

                <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                    {filteredActivities.map(activity => (
                        <LevelCard
                            key={activity.id}
                            topic={activity.title}
                            ageRange={activity.ageRange}
                            description={activity.content || `Learn about ${activity.title}`}
                            type={activity.type || 'lesson'}
                            onComplete={() => handleComplete(activity.id)}
                        />
                    ))}
                </div>
            </>
        );
    };

    const renderSubtopics = () => {
        if (!selectedKeyStage || !selectedTopic) return null;
        
        const topic = mathematicsCurriculum[selectedKeyStage].topics
            .find(t => t.id === selectedTopic);
        
        if (!topic) return null;

        return (
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                {topic.subtopics.map(subtopic => {
                    const activities = 'activities' in subtopic ? subtopic.activities : 
                                     'lessons' in subtopic ? subtopic.lessons : [];
                    const activityCounts = countActivityTypes(activities);
                    
                    return (
                        <motion.button
                            key={subtopic.id}
                            onClick={() => setSelectedSubtopic(subtopic.id)}
                            className="p-6 bg-white rounded-xl shadow-lg transition-all text-left hover:shadow-xl"
                            whileHover={{ scale: 1.02 }}
                        >
                            <h3 className="text-xl font-bold mb-2">{subtopic.title}</h3>
                            <p className="text-neutral-600 mb-4">
                                {subtopic.description || `Learn about ${subtopic.title}`}
                            </p>
                            <div className="flex gap-4 text-sm text-neutral-500">
                                {activityCounts.lesson && (
                                    <span className="flex items-center">
                                        <BookOpen className="w-4 h-4 mr-1" />
                                        {activityCounts.lesson} Lessons
                                    </span>
                                )}
                                {activityCounts.quiz && (
                                    <span className="flex items-center">
                                        <Brain className="w-4 h-4 mr-1" />
                                        {activityCounts.quiz} Quizzes
                                    </span>
                                )}
                                {activityCounts.game && (
                                    <span className="flex items-center">
                                        <Gamepad className="w-4 h-4 mr-1" />
                                        {activityCounts.game} Games
                                    </span>
                                )}
                            </div>
                        </motion.button>
                    );
                })}
            </div>
        );
    };

    const renderTopics = () => {
        if (!selectedKeyStage) return null;

        return (
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                {mathematicsCurriculum[selectedKeyStage].topics.map(topic => {
                    const allActivities = topic.subtopics.flatMap(st => 
                        'activities' in st ? st.activities : 
                        'lessons' in st ? st.lessons : []
                    );
                    const activityCounts = countActivityTypes(allActivities);
                    
                    return (
                        <motion.button
                            key={topic.id}
                            onClick={() => setSelectedTopic(topic.id)}
                            className="p-6 bg-white rounded-xl shadow-lg transition-all text-left hover:shadow-xl"
                            whileHover={{ scale: 1.02 }}
                        >
                            <h3 className="text-xl font-bold mb-2">{topic.title}</h3>
                            <div className="flex gap-4 text-sm text-neutral-500">
                                {activityCounts.lesson && (
                                    <span className="flex items-center">
                                        <BookOpen className="w-4 h-4 mr-1" />
                                        {activityCounts.lesson} Lessons
                                    </span>
                                )}
                                {activityCounts.quiz && (
                                    <span className="flex items-center">
                                        <Brain className="w-4 h-4 mr-1" />
                                        {activityCounts.quiz} Quizzes
                                    </span>
                                )}
                                {activityCounts.game && (
                                    <span className="flex items-center">
                                        <Gamepad className="w-4 h-4 mr-1" />
                                        {activityCounts.game} Games
                                    </span>
                                )}
                            </div>
                        </motion.button>
                    );
                })}
            </div>
        );
    };

    const getBreadcrumbs = () => {
        const parts = [];
        if (selectedKeyStage) {
            parts.push(mathematicsCurriculum[selectedKeyStage].title);
        }
        if (selectedTopic) {
            const topic = mathematicsCurriculum[selectedKeyStage!].topics
                .find(t => t.id === selectedTopic);
            if (topic) parts.push(topic.title);
        }
        if (selectedSubtopic) {
            const topic = mathematicsCurriculum[selectedKeyStage!].topics
                .find(t => t.id === selectedTopic);
            const subtopic = topic?.subtopics.find(s => s.id === selectedSubtopic);
            if (subtopic) parts.push(subtopic.title);
        }
        return parts;
    };

    const handleBack = () => {
        if (selectedSubtopic) {
            setSelectedSubtopic(null);
            setSelectedType(null);
        }
        else if (selectedTopic) setSelectedTopic(null);
        else if (selectedKeyStage) setSelectedKeyStage(null);
    };

    const breadcrumbs = getBreadcrumbs();

    return (
        <div className="p-8">
            <div className="flex items-center gap-4 mb-8">
                {(selectedKeyStage || selectedTopic || selectedSubtopic) && (
                    <button 
                        onClick={handleBack}
                        className="flex items-center text-neutral-600 hover:text-neutral-800"
                    >
                        <ArrowLeft className="w-5 h-5 mr-2" />
                        Back
                    </button>
                )}
                {breadcrumbs.length > 0 && (
                    <div className="text-sm text-neutral-600">
                        {breadcrumbs.join(' / ')}
                    </div>
                )}
            </div>
            
            {selectedSubtopic && renderActivities()}
            {selectedTopic && !selectedSubtopic && renderSubtopics()}
            {selectedKeyStage && !selectedTopic && renderTopics()}
            {!selectedKeyStage && renderKeyStages()}
        </div>
    );
}