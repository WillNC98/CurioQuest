import React from 'react';
import { motion } from 'framer-motion';
import { Subtopic } from '../../../data/mathematics/types';

interface SubtopicCardProps {
  subtopic: Subtopic;
  onClick: () => void;
}

export function SubtopicCard({ subtopic, onClick }: SubtopicCardProps) {
  return (
    <motion.button
      onClick={onClick}
      className="w-full p-6 bg-white rounded-xl shadow-lg hover:shadow-xl transition-all text-left"
      whileHover={{ scale: 1.02 }}
      whileTap={{ scale: 0.98 }}
    >
      <h3 className="text-xl font-bold mb-2">{subtopic.title}</h3>
      <p className="text-neutral-600 mb-4">{subtopic.description}</p>
      <div className="text-sm text-neutral-500">
        {subtopic.lessons.length} {subtopic.lessons.length === 1 ? 'Lesson' : 'Lessons'}
      </div>
    </motion.button>
  );
}