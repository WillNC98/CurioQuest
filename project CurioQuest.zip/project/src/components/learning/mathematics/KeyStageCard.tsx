import React from 'react';
import { motion } from 'framer-motion';
import { Book } from 'lucide-react';
import { KeyStageContent } from '../../../data/mathematics/types';

interface KeyStageCardProps {
  keyStage: KeyStageContent;
  onClick: () => void;
}

export function KeyStageCard({ keyStage, onClick }: KeyStageCardProps) {
  const totalLessons = keyStage.topics.reduce(
    (acc, topic) => acc + topic.subtopics.reduce(
      (acc2, subtopic) => acc2 + subtopic.lessons.length,
      0
    ),
    0
  );

  return (
    <motion.button
      onClick={onClick}
      className="w-full p-8 bg-primary/10 rounded-2xl hover:bg-primary/20 transition-all text-left"
      whileHover={{ scale: 1.05 }}
      whileTap={{ scale: 0.98 }}
    >
      <div className="flex items-center gap-4 mb-4">
        <div className="p-3 bg-white rounded-xl">
          <Book className="h-6 w-6 text-primary" />
        </div>
        <div>
          <h2 className="text-2xl font-bold">{keyStage.title}</h2>
          <p className="text-neutral-600">Ages {keyStage.ageRange}</p>
        </div>
      </div>
      <p className="text-neutral-600 mb-4">{keyStage.description}</p>
      <div className="text-sm text-neutral-500">
        {totalLessons} {totalLessons === 1 ? 'Lesson' : 'Lessons'} • {keyStage.topics.length} {keyStage.topics.length === 1 ? 'Topic' : 'Topics'}
      </div>
    </motion.button>
  );
}