import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { ArrowLeft, BookOpen, Gamepad, Award } from 'lucide-react';
import { englishCurriculum } from '../../../data/english/curriculum';
import { LevelCard } from '../LevelCard/LevelCard';
import { useAuth } from '../../../features/auth/hooks/useAuth';
import { updateUserProgress } from '../../../services/learning/progressService';

export function EnglishHub() {
    const { user } = useAuth();
    const [selectedKeyStage, setSelectedKeyStage] = useState<string | null>(null);
    const [selectedTopic, setSelectedTopic] = useState<string | null>(null);
    const [selectedSubtopic, setSelectedSubtopic] = useState<string | null>(null);
    const [selectedType, setSelectedType] = useState<'lesson' | 'quiz' | 'game' | null>(null);

    const handleComplete = async (activityId: string) => {
        if (!user?.uid) return;
        await updateUserProgress(user.uid, activityId);
    };

    const renderKeyStages = () => {
        const keyStages = [
            { id: 'key-stage-1', title: 'Key Stage 1', ageRange: '5-7', description: 'Foundation English skills including phonics, reading, writing, and grammar' }
        ];

        return (
            <div className="grid gap-6 md:grid-cols-2">
                {keyStages.map((stage, index) => (
                    <motion.button
                        key={stage.id}
                        onClick={() => setSelectedKeyStage(stage.id)}
                        className="p-8 bg-primary/10 rounded-xl shadow-lg transition-all text-left"
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: index * 0.1 }}
                        whileHover={{ scale: 1.05 }}
                    >
                        <h2 className="text-2xl font-bold mb-2">
                            {stage.title}
                        </h2>
                        <p className="text-neutral-600 mb-2">Ages {stage.ageRange}</p>
                        <p className="text-neutral-500 text-sm">{stage.description}</p>
                    </motion.button>
                ))}
            </div>
        );
    };

    const renderTopics = () => {
        if (!selectedKeyStage) return null;

        const topics = englishCurriculum.topics || [];
        return (
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                {topics.map(topic => (
                    <motion.button
                        key={topic.id}
                        onClick={() => setSelectedTopic(topic.id)}
                        className="p-6 bg-white rounded-xl shadow-lg transition-all text-left"
                        whileHover={{ scale: 1.02 }}
                    >
                        <h3 className="text-xl font-bold mb-2">{topic.title}</h3>
                        <p className="text-neutral-600">
                            {topic.subtopics.length} {topic.subtopics.length === 1 ? 'Subtopic' : 'Subtopics'}
                        </p>
                    </motion.button>
                ))}
            </div>
        );
    };

    const renderSubtopics = () => {
        if (!selectedKeyStage || !selectedTopic) return null;
        
        const topic = englishCurriculum.topics.find(t => t.id === selectedTopic);
        if (!topic) return null;

        return (
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                {topic.subtopics.map(subtopic => (
                    <motion.button
                        key={subtopic.id}
                        onClick={() => setSelectedSubtopic(subtopic.id)}
                        className="p-6 bg-white rounded-xl shadow-lg transition-all text-left"
                        whileHover={{ scale: 1.02 }}
                    >
                        <h3 className="text-xl font-bold mb-2">{subtopic.title}</h3>
                        <p className="text-neutral-600 mb-2">{subtopic.description}</p>
                        <div className="flex gap-4 mt-4">
                            <span className="text-sm text-neutral-500 flex items-center">
                                <BookOpen className="w-4 h-4 mr-1" />
                                {subtopic.lessons.filter(l => l.type === 'lesson').length} Lessons
                            </span>
                            <span className="text-sm text-neutral-500 flex items-center">
                                <Award className="w-4 h-4 mr-1" />
                                {subtopic.lessons.filter(l => l.type === 'quiz').length} Quizzes
                            </span>
                            <span className="text-sm text-neutral-500 flex items-center">
                                <Gamepad className="w-4 h-4 mr-1" />
                                {subtopic.lessons.filter(l => l.type === 'game').length} Games
                            </span>
                        </div>
                    </motion.button>
                ))}
            </div>
        );
    };

    const renderActivities = () => {
        if (!selectedKeyStage || !selectedTopic || !selectedSubtopic) return null;

        const topic = englishCurriculum.topics.find(t => t.id === selectedTopic);
        const subtopic = topic?.subtopics.find(s => s.id === selectedSubtopic);

        if (!subtopic) return null;

        const activities = subtopic.lessons.filter(l => !selectedType || l.type === selectedType);

        return (
            <>
                <div className="flex gap-4 mb-6">
                    <button
                        onClick={() => setSelectedType(null)}
                        className={`px-4 py-2 rounded-lg transition-colors ${!selectedType ? 'bg-primary text-white' : 'bg-gray-100 hover:bg-gray-200'}`}
                    >
                        All
                    </button>
                    <button
                        onClick={() => setSelectedType('lesson')}
                        className={`px-4 py-2 rounded-lg transition-colors ${selectedType === 'lesson' ? 'bg-primary text-white' : 'bg-gray-100 hover:bg-gray-200'}`}
                    >
                        Lessons
                    </button>
                    <button
                        onClick={() => setSelectedType('quiz')}
                        className={`px-4 py-2 rounded-lg transition-colors ${selectedType === 'quiz' ? 'bg-primary text-white' : 'bg-gray-100 hover:bg-gray-200'}`}
                    >
                        Quizzes
                    </button>
                    <button
                        onClick={() => setSelectedType('game')}
                        className={`px-4 py-2 rounded-lg transition-colors ${selectedType === 'game' ? 'bg-primary text-white' : 'bg-gray-100 hover:bg-gray-200'}`}
                    >
                        Games
                    </button>
                </div>

                <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                    {activities.map(activity => (
                        <LevelCard
                            key={activity.id}
                            topic={activity.title}
                            ageRange={activity.ageRange}
                            description={activity.content}
                            type={activity.type}
                            onComplete={() => handleComplete(activity.id)}
                        />
                    ))}
                </div>
            </>
        );
    };

    const getBreadcrumbs = () => {
        const parts = [];
        if (selectedKeyStage) {
            parts.push('English');
        }
        if (selectedTopic) {
            const topic = englishCurriculum.topics.find(t => t.id === selectedTopic);
            if (topic) parts.push(topic.title);
        }
        if (selectedSubtopic) {
            const topic = englishCurriculum.topics.find(t => t.id === selectedTopic);
            const subtopic = topic?.subtopics.find(s => s.id === selectedSubtopic);
            if (subtopic) parts.push(subtopic.title);
        }
        return parts;
    };

    const handleBack = () => {
        if (selectedType) setSelectedType(null);
        else if (selectedSubtopic) setSelectedSubtopic(null);
        else if (selectedTopic) setSelectedTopic(null);
        else if (selectedKeyStage) setSelectedKeyStage(null);
    };

    const breadcrumbs = getBreadcrumbs();

    return (
        <div className="p-8">
            <div className="flex items-center gap-4 mb-8">
                {(selectedKeyStage || selectedTopic || selectedSubtopic || selectedType) && (
                    <button 
                        onClick={handleBack}
                        className="flex items-center text-neutral-600 hover:text-neutral-800"
                    >
                        <ArrowLeft className="w-5 h-5 mr-2" />
                        Back
                    </button>
                )}
                {breadcrumbs.length > 0 && (
                    <div className="text-sm text-neutral-600">
                        {breadcrumbs.join(' / ')}
                    </div>
                )}
            </div>
            
            {selectedSubtopic && renderActivities()}
            {selectedTopic && !selectedSubtopic && renderSubtopics()}
            {selectedKeyStage && !selectedTopic && renderTopics()}
            {!selectedKeyStage && renderKeyStages()}
        </div>
    );
}