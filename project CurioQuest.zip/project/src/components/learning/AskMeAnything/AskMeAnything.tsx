import React, { useState } from 'react';
import { Camera, Search, Upload, Sparkles } from 'lucide-react';
import { motion } from 'framer-motion';
import { useAuth } from '../../../features/auth/hooks/useAuth';
import { generateLearningContent } from '../../../services/ai/generators';
import { analyzeImage } from '../../../services/ai/imageAnalysis';
import { ErrorMessage } from '../../common/ErrorMessage/ErrorMessage';
import './AskMeAnything.css';

interface AskMeAnythingProps {
  defaultComplexity?: number;
}

export function AskMeAnything({ defaultComplexity = 1 }: AskMeAnythingProps) {
  const { user } = useAuth();
  const [query, setQuery] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [complexity, setComplexity] = useState(defaultComplexity);
  const [responseType, setResponseType] = useState<'text' | 'video' | 'quiz'>('text');
  const [responseLength, setResponseLength] = useState<'short' | 'medium' | 'long'>('medium');
  const [response, setResponse] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent): Promise<void> => {
    e.preventDefault();
    if (!query.trim()) return;

    setIsLoading(true);
    setError(null);
    setResponse(null);

    try {
      const result = await generateLearningContent(query, {
        complexity,
        responseType,
        responseLength
      });
      setResponse(result.content);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred while generating content');
    } finally {
      setIsLoading(false);
    }
  };

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>): Promise<void> => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsLoading(true);
    setError(null);
    setResponse(null);

    try {
      // Convert image to base64
      const reader = new FileReader();
      reader.onloadend = async () => {
        try {
          const base64Image = reader.result as string;
          const analysisResult = await analyzeImage(base64Image);
          setResponse(analysisResult);
        } catch (err) {
          setError(err instanceof Error ? err.message : 'Failed to analyze image');
        } finally {
          setIsLoading(false);
        }
      };
      reader.readAsDataURL(file);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to process image');
      setIsLoading(false);
    }
  };

  return (
    <div className="ask-me-anything">
      <motion.div 
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="search-container"
      >
        <form onSubmit={handleSubmit} className="search-form">
          <div className="input-wrapper">
            <Search className="search-icon" />
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Ask me anything..."
              className="search-input"
              aria-label="Search query"
            />
            {isLoading && <Sparkles className="loading-icon" />}
          </div>
          
          <div className="actions">
            <label className="upload-button" role="button" aria-label="Take photo">
              <Camera className="icon" />
              <input
                type="file"
                accept="image/*"
                capture="environment"
                onChange={handleImageUpload}
                className="hidden"
              />
            </label>
            <label className="upload-button" role="button" aria-label="Upload image">
              <Upload className="icon" />
              <input
                type="file"
                accept="image/*"
                onChange={handleImageUpload}
                className="hidden"
              />
            </label>
          </div>
        </form>

        <div className="controls">
          <div className="control-group">
            <label htmlFor="complexity">Complexity</label>
            <select 
              id="complexity"
              value={complexity} 
              onChange={(e) => setComplexity(Number(e.target.value))}
              className="select-input"
            >
              <option value={1}>Simple (Ages 4-7)</option>
              <option value={2}>Basic (Ages 8-11)</option>
              <option value={3}>Intermediate (Ages 12-15)</option>
            </select>
          </div>

          <div className="control-group">
            <label htmlFor="responseType">Response Type</label>
            <select 
              id="responseType"
              value={responseType}
              onChange={(e) => setResponseType(e.target.value as any)}
              className="select-input"
            >
              <option value="text">Text</option>
              <option value="video">Video</option>
              <option value="quiz">Quiz</option>
            </select>
          </div>

          <div className="control-group">
            <label htmlFor="responseLength">Length</label>
            <select
              id="responseLength"
              value={responseLength}
              onChange={(e) => setResponseLength(e.target.value as any)}
              className="select-input"
            >
              <option value="short">Short</option>
              <option value="medium">Medium</option>
              <option value="long">Long</option>
            </select>
          </div>
        </div>

        {error && (
          <div className="mt-4">
            <ErrorMessage error={error} />
          </div>
        )}

        {response && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="response-container"
          >
            <h3 className="text-lg font-semibold mb-2">Response:</h3>
            <div className="response-content">
              {response}
            </div>
          </motion.div>
        )}
      </motion.div>
    </div>
  );
}