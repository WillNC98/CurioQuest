import React from 'react';
import { BookOpen, Brain, Trophy } from 'lucide-react';
import { FeatureCard } from './FeatureCard';

export function FeaturesSection() {
  return (
    <div className="mt-24">
      <h2 className="text-3xl font-display font-semibold text-neutral-800 text-center mb-12 drop-shadow-sm">
        Why Choose CurioQuest?
      </h2>
      
      <div className="grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-3">
        <FeatureCard
          icon={<Brain className="h-10 w-10" />}
          title="Adaptive Learning"
          description="Personalized learning paths that adapt to your progress and interests."
          color="primary"
        />
        <FeatureCard
          icon={<Trophy className="h-10 w-10" />}
          title="Achievement System"
          description="Earn badges and track your progress as you complete challenges."
          color="secondary"
        />
        <FeatureCard
          icon={<BookOpen className="h-10 w-10" />}
          title="Rich Content"
          description="Access a vast library of curated educational content across various topics."
          color="accent"
        />
      </div>
    </div>
  );
}