import React from 'react';
import { motion } from 'framer-motion';

interface FeatureCardProps {
  icon: React.ReactNode;
  title: string;
  description: string;
  color: 'primary' | 'secondary' | 'accent';
}

const colorClasses = {
  primary: {
    bg: 'bg-primary/5',
    text: 'text-primary',
    hover: 'hover:bg-primary/10'
  },
  secondary: {
    bg: 'bg-secondary/5',
    text: 'text-secondary-dark',
    hover: 'hover:bg-secondary/10'
  },
  accent: {
    bg: 'bg-accent/5',
    text: 'text-accent',
    hover: 'hover:bg-accent/10'
  }
};

export function FeatureCard({ icon, title, description, color }: FeatureCardProps) {
  const colors = colorClasses[color];
  
  return (
    <motion.div
      whileHover={{ scale: 1.05 }}
      className={`p-8 rounded-2xl ${colors.bg} ${colors.hover} transition-colors duration-200`}
    >
      <div className={`mb-6 ${colors.text}`}>
        {icon}
      </div>
      <h3 className="text-xl font-serif font-bold text-neutral-800 mb-3">{title}</h3>
      <p className="text-neutral-600 leading-relaxed">{description}</p>
    </motion.div>
  );
}