import React from 'react';
import './PaintSplash.css';

interface PaintSplashProps {
  color: string;
  className?: string;
}

export function PaintSplash({ color, className = '' }: PaintSplashProps) {
  return (
    <svg 
      viewBox="0 0 200 200" 
      className={`paint-splash ${className}`}
      style={{ '--splash-color': color } as React.CSSProperties}
    >
      <path d="M100 0C80 20 60 40 40 60C20 80 0 100 20 120C40 140 60 160 80 180C100 200 120 180 140 160C160 140 180 120 160 100C140 80 120 60 100 0Z" />
    </svg>
  );
}