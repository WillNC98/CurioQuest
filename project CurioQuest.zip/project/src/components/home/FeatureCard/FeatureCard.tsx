import React from 'react';
import { motion } from 'framer-motion';
import { PaintSplash } from './PaintSplash';
import './FeatureCard.css';

interface FeatureCardProps {
  icon: React.ReactNode;
  title: string;
  description: string;
  color: 'primary' | 'secondary' | 'accent';
}

const colorMap = {
  primary: '#FF7F50',   // Coral
  secondary: '#FFD700', // Gold
  accent: '#32CD32'     // Lime Green
};

export function FeatureCard({ icon, title, description, color }: FeatureCardProps) {
  return (
    <motion.div
      whileHover={{ scale: 1.05 }}
      className="feature-card"
    >
      <PaintSplash color={colorMap[color]} />
      <div className="feature-content">
        <div className={`feature-icon text-${color}`}>
          {icon}
        </div>
        <h3 className="feature-title">{title}</h3>
        <p className="feature-description">{description}</p>
      </div>
    </motion.div>
  );
}