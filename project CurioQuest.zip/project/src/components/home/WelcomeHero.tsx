import React from 'react';
import { Sparkles, ArrowRight } from 'lucide-react';
import { Button } from '../common/Button';

export function WelcomeHero() {
  const handleAuthClick = () => {
    window.location.href = '/welcome-hero';
  };

  return (
    <div className="relative py-20 md:py-32 text-center">
      <div className="relative z-10 space-y-8">
        <div className="inline-flex items-center px-4 py-2 rounded-full bg-primary/10 text-primary animate-float backdrop-blur-sm">
          <Sparkles className="h-5 w-5 mr-2" />
          <span className="font-medium">Embark on Your Learning Adventure</span>
        </div>
        
        <h1 className="text-4xl md:text-5xl lg:text-6xl font-display font-extrabold text-neutral-800 tracking-tight max-w-4xl mx-auto leading-tight">
          Discover the Joy of 
          <span className="text-primary relative ml-3">
            Learning
            <span className="absolute -top-1 -right-4 text-2xl">✨</span>
          </span>
        </h1>
        
        <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mt-8">
          <Button 
            size="lg"
            className="min-w-[200px] transform hover:scale-105 transition-transform duration-200 shadow-lg hover:shadow-xl group"
            onClick={handleAuthClick}
          >
            <span>Get Started</span>
            <ArrowRight className="h-5 w-5 ml-2 group-hover:translate-x-1 transition-transform" />
          </Button>
          
          <Button 
            variant="outline"
            size="lg"
            className="min-w-[200px]"
            onClick={handleAuthClick}
          >
            Sign In
          </Button>
        </div>
      </div>
    </div>
  );
}