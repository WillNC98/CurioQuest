import React from 'react';
import './AchievementBadge.css';

interface AchievementBadgeProps {
  title: string;
  icon: React.ReactNode;
  level?: 'bronze' | 'silver' | 'gold';
  unlocked?: boolean;
}

export function AchievementBadge({
  title,
  icon,
  level = 'bronze',
  unlocked = false,
}: AchievementBadgeProps) {
  return (
    <div className={`achievement-badge ${level} ${unlocked ? 'unlocked' : 'locked'}`}>
      <div className="badge-icon">{icon}</div>
      <p className="badge-title">{title}</p>
      {!unlocked && <div className="badge-overlay" />}
    </div>
  );
}