import React from 'react';
import { X } from 'lucide-react';
import { LoginForm } from '../../features/auth/components/LoginForm';
import { RegisterForm } from '../../features/auth/components/RegisterForm';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialView?: 'login' | 'register';
}

export function AuthModal({ isOpen, onClose, initialView = 'login' }: AuthModalProps) {
  const [view, setView] = React.useState(initialView);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto">
      <div className="flex min-h-screen items-center justify-center p-4">
        {/* Backdrop */}
        <div 
          className="fixed inset-0 bg-black/50 backdrop-blur-sm transition-opacity"
          onClick={onClose}
        />

        {/* Modal */}
        <div className="relative z-10 w-full max-w-md transform rounded-2xl bg-white shadow-2xl transition-all">
          {/* Close Button */}
          <button
            onClick={onClose}
            className="absolute right-4 top-4 text-neutral-400 hover:text-neutral-600"
          >
            <X className="h-6 w-6" />
          </button>

          {/* Content */}
          <div className="p-8">
            {view === 'login' ? (
              <LoginForm onSuccess={onClose} onRegister={() => setView('register')} />
            ) : (
              <RegisterForm onSuccess={onClose} onLogin={() => setView('login')} />
            )}
          </div>
        </div>
      </div>
    </div>
  );
}