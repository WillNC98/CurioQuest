import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { AuthInput } from './AuthInput';
import { Button } from '../common/Button';
import { useAuth } from '../../features/auth/hooks/useAuth';

interface LoginFormProps {
  onSuccess?: () => void;
  onRegister?: () => void;
}

export function LoginForm({ onSuccess, onRegister }: LoginFormProps) {
  const navigate = useNavigate();
  const { login } = useAuth();
  const [formData, setFormData] = useState({ email: '', password: '' });
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setIsLoading(true);

    try {
      await login(formData.email, formData.password);
      onSuccess?.();
      navigate('/welcome-hero');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Login failed');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h2 className="text-2xl font-display font-bold text-neutral-800">Welcome Back!</h2>
        <p className="mt-2 text-sm text-neutral-600">Sign in to continue your learning journey</p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        <AuthInput
          id="email"
          label="Email Address"
          type="email"
          value={formData.email}
          onChange={e => setFormData(prev => ({ ...prev, email: e.target.value }))}
          required
        />

        <AuthInput
          id="password"
          label="Password"
          type="password"
          value={formData.password}
          onChange={e => setFormData(prev => ({ ...prev, password: e.target.value }))}
          required
        />

        {error && (
          <div className="text-sm text-red-500 bg-red-50 p-3 rounded-lg">
            {error}
          </div>
        )}

        <Button
          type="submit"
          className="w-full"
          disabled={isLoading}
        >
          {isLoading ? 'Signing in...' : 'Sign in'}
        </Button>
      </form>

      <p className="text-center text-sm text-neutral-600">
        New to CurioQuest?{' '}
        <button
          type="button"
          onClick={onRegister}
          className="text-primary hover:underline"
        >
          Create an account
        </button>
      </p>
    </div>
  );
}