import React from 'react';
import { Button } from '../common/Button';

interface TestFormProps {
  input: string;
  onInputChange: (value: string) => void;
  onTest: () => void;
  isLoading?: boolean;
}

export function TestForm({ input, onInputChange, onTest, isLoading = false }: TestFormProps) {
  return (
    <div className="space-y-4">
      <div>
        <label htmlFor="test-input" className="block text-sm font-medium text-gray-700 mb-1">
          Test Input
        </label>
        <input
          id="test-input"
          type="text"
          value={input}
          onChange={(e) => onInputChange(e.target.value)}
          className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-primary focus:border-primary"
          placeholder="Enter test prompt..."
        />
      </div>
      
      <Button
        onClick={onTest}
        disabled={isLoading}
        className="w-full"
      >
        {isLoading ? 'Testing...' : 'Test'}
      </Button>
    </div>
  );
}