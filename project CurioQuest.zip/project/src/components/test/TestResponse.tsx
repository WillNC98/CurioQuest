import React from 'react';
import { LoadingSpinner } from '../common/LoadingSpinner/LoadingSpinner';
import { ErrorMessage } from '../common/ErrorMessage/ErrorMessage';

interface TestResponseProps {
  response: string;
  error?: string | null;
  isLoading: boolean;
}

export function TestResponse({ response, error, isLoading }: TestResponseProps) {
  if (isLoading) {
    return (
      <div className="flex justify-center py-8">
        <LoadingSpinner size="lg" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="mt-6">
        <ErrorMessage error={error} />
        {error.includes('quota exceeded') && (
          <div className="mt-2 text-sm text-gray-600">
            <span>To resolve this:</span>
            <ol className="list-decimal ml-5 mt-1">
              <li>Visit your <a href="https://platform.openai.com/account/billing" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">OpenAI billing dashboard</a></li>
              <li>Check your current usage and limits</li>
              <li>Add billing information or upgrade your plan if needed</li>
            </ol>
          </div>
        )}
      </div>
    );
  }

  if (!response) {
    return null;
  }

  return (
    <div className="mt-6 p-4 bg-gray-50 rounded-lg">
      <h3 className="text-sm font-medium text-gray-700 mb-2">Response:</h3>
      <div className="text-gray-900 whitespace-pre-wrap">{response}</div>
    </div>
  );
}