import React from 'react';

interface ErrorMessageProps {
  error: Error | string;
  className?: string;
}

export function ErrorMessage({ error, className = '' }: ErrorMessageProps) {
  const message = error instanceof Error ? error.message : error;
  
  return (
    <div className={`bg-red-50 text-red-500 p-3 rounded-lg text-sm ${className}`}>
      {message}
    </div>
  );
}