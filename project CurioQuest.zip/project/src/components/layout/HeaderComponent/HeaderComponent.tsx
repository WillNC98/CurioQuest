import React from 'react';
import { Menu, Search, User } from 'lucide-react';
import './HeaderComponent.css';

export function HeaderComponent() {
  return (
    <header className="header-container">
      <div className="header-content">
        <div className="header-left">
          <button className="menu-button">
            <span className="sr-only">Open menu</span>
            <Menu className="h-6 w-6" />
          </button>
          <div className="logo-container">
            <h1 className="logo-text">CurioQuest</h1>
          </div>
        </div>
        
        <div className="search-container">
          <div className="search-wrapper">
            <label htmlFor="search" className="sr-only">Search</label>
            <div className="search-input-wrapper">
              <Search className="search-icon" />
              <input
                id="search"
                className="search-input"
                placeholder="Search"
                type="search"
              />
            </div>
          </div>
        </div>

        <div className="header-right">
          <button className="profile-button">
            <span className="sr-only">View profile</span>
            <User className="h-6 w-6" />
          </button>
        </div>
      </div>
    </header>
  );
}