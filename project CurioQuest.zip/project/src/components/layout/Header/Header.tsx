import React from 'react';
import { Menu, Search, User, LogOut } from 'lucide-react';
import { Logo } from './Logo';
import { SearchBar } from './SearchBar';
import { useAuth } from '../../../features/auth/hooks/useAuth';
import './Header.css';

export function Header() {
  const { user, logout } = useAuth();

  const handleLogout = async () => {
    try {
      await logout();
    } catch (error) {
      console.error('Logout failed:', error);
    }
  };

  return (
    <header className="bg-white shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center">
            <button className="menu-button">
              <span className="sr-only">Open menu</span>
              <Menu className="h-6 w-6 text-neutral-600" />
            </button>
            <Logo />
          </div>
          
          <SearchBar />

          <div className="flex items-center gap-4">
            {user ? (
              <>
                <div className="text-sm text-neutral-600">
                  {user.displayName || user.email}
                </div>
                <button 
                  onClick={handleLogout}
                  className="profile-button"
                  title="Sign out"
                >
                  <LogOut className="h-5 w-5 text-neutral-600" />
                </button>
              </>
            ) : (
              <button className="profile-button">
                <span className="sr-only">View profile</span>
                <User className="h-6 w-6 text-neutral-600" />
              </button>
            )}
          </div>
        </div>
      </div>
    </header>
  );
}