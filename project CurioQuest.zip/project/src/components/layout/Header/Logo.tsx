import React from 'react';
import { Sparkle } from 'lucide-react';

export function Logo() {
  return (
    <div className="flex-shrink-0 flex items-center">
      <h1 className="text-2xl font-bold text-coral drop-shadow-glow flex items-center">
        CurioQuest
        <Sparkle className="h-5 w-5 ml-1 text-coral" />
      </h1>
    </div>
  );
}