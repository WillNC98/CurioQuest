import React from 'react';
import { Search } from 'lucide-react';

export function SearchBar() {
  return (
    <div className="flex-1 flex justify-center px-2 lg:ml-6 lg:justify-end">
      <div className="max-w-lg w-full lg:max-w-xs">
        <label htmlFor="search" className="sr-only">Search</label>
        <div className="relative">
          <Search className="search-icon text-white/70" />
          <input
            id="search"
            className="search-input bg-white/10 text-white placeholder-white/70"
            placeholder="Search"
            type="search"
          />
        </div>
      </div>
    </div>
  );
}