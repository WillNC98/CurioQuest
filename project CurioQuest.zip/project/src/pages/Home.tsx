import React from 'react';
import { Header } from '../components/layout/Header/Header';
import { WelcomeHero } from '../components/home/WelcomeHero';
import { FeaturesSection } from '../components/home/FeaturesSection';
import { ArrowRight } from 'lucide-react';

export function Home() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-white to-neutral-50">
      <Header />
      
      {/* Hero Section */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <WelcomeHero />
        
        {/* Decorative Element */}
        <div className="relative my-24">
          <div className="absolute inset-0 flex items-center" aria-hidden="true">
            <div className="w-full border-t border-neutral-200" />
          </div>
          <div className="relative flex justify-center">
            <div className="bg-white px-4 flex items-center gap-2">
              <span className="text-neutral-500">Discover More</span>
              <ArrowRight className="h-4 w-4 text-primary animate-bounce" />
            </div>
          </div>
        </div>

        <FeaturesSection />

        {/* Call to Action */}
        <div className="mt-24 mb-16 text-center">
          <div className="relative rounded-2xl bg-primary/5 p-8 md:p-12 overflow-hidden">
            <div className="relative z-10">
              <h2 className="text-2xl md:text-3xl font-display font-bold text-neutral-800 mb-4">
                Ready to Start Your Learning Journey?
              </h2>
              <p className="text-neutral-600 mb-8 max-w-2xl mx-auto">
                Join thousands of curious minds exploring new horizons of knowledge every day.
              </p>
              <button className="bg-primary text-white px-8 py-3 rounded-xl font-medium 
                               hover:bg-primary-dark transform hover:scale-105 transition-all duration-200
                               shadow-lg hover:shadow-xl">
                Get Started Now
              </button>
            </div>
            
            {/* Background Decoration */}
            <div className="absolute top-0 left-0 w-full h-full pointer-events-none">
              <div className="absolute top-0 left-0 w-64 h-64 bg-primary/10 rounded-full -translate-x-1/2 -translate-y-1/2" />
              <div className="absolute bottom-0 right-0 w-96 h-96 bg-secondary/10 rounded-full translate-x-1/3 translate-y-1/3" />
            </div>
          </div>
        </div>

        {/* Trust Indicators */}
        <div className="text-center pb-16">
          <div className="flex flex-wrap justify-center gap-8 text-neutral-600 text-sm">
            <div>🔒 Secure Learning Environment</div>
            <div>⭐ 4.9/5 Student Satisfaction</div>
            <div>📚 1000+ Learning Resources</div>
            <div>🌟 Award-winning Platform</div>
          </div>
        </div>
      </main>
    </div>
  );
}