import React from 'react';
import { HeaderComponent } from '../../components/layout/HeaderComponent/HeaderComponent';
import { Trophy, Book, Target } from 'lucide-react';
import './DashboardPage.css';

export function DashboardPage() {
  return (
    <div className="min-h-screen">
      <HeaderComponent />
      <main className="container mx-auto px-4 py-8">
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          <div className="stats-card">
            <Trophy className="h-8 w-8 text-primary" />
            <h3 className="text-xl font-display">Achievements</h3>
            <p className="text-3xl font-bold">12</p>
          </div>
          
          <div className="stats-card">
            <Book className="h-8 w-8 text-secondary" />
            <h3 className="text-xl font-display">Courses</h3>
            <p className="text-3xl font-bold">5</p>
          </div>
          
          <div className="stats-card">
            <Target className="h-8 w-8 text-accent" />
            <h3 className="text-xl font-display">Goals</h3>
            <p className="text-3xl font-bold">3</p>
          </div>
        </div>

        <section className="mt-12">
          <h2 className="text-2xl font-display mb-6">Continue Learning</h2>
          <div className="grid gap-6 md:grid-cols-2">
            {/* Course cards will be dynamically rendered here */}
          </div>
        </section>
      </main>
    </div>
  );
}