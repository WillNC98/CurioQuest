import React, { useState } from 'react';
import { generateLearningContent } from '../services/ai/generators';
import { TestForm } from '../components/test/TestForm';
import { TestResponse } from '../components/test/TestResponse';

export function TestPage() {
  const [input, setInput] = useState('Hello World');
  const [response, setResponse] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const handleTest = async () => {
    setIsLoading(true);
    setError(null);
    
    try {
      const result = await generateLearningContent(input);
      setResponse(result.content);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-xl mx-auto px-4">
        <div className="bg-white rounded-xl shadow-sm p-6">
          <h1 className="text-2xl font-display font-bold text-gray-900 mb-6">
            Test AI Integration
          </h1>
          
          <TestForm
            input={input}
            onInputChange={setInput}
            onTest={handleTest}
            isLoading={isLoading}
          />
          
          <TestResponse
            response={response}
            error={error}
            isLoading={isLoading}
          />
        </div>
      </div>
    </div>
  );
}