import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ArrowLeft } from 'lucide-react';
import { MathematicsHub } from '../../components/learning/mathematics/MathematicsHub';
import { EnglishHub } from '../../components/learning/english/EnglishHub';
import { LoadingSpinner } from '../../components/common/LoadingSpinner/LoadingSpinner';
import { useAuth } from '../../features/auth/hooks/useAuth';
import { fetchUserProgress } from '../../services/learning/progressService';
import './QuestsPage.css';

export function QuestsPage() {
  const navigate = useNavigate();
  const { subject } = useParams(); // Get the subject from URL params
  const { user } = useAuth();
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let mounted = true;

    async function loadProgress() {
      try {
        if (user?.uid) {
          await fetchUserProgress(user.uid);
        }
      } catch (error) {
        console.error('Error loading progress:', error);
        if (mounted) {
          setError('Failed to load progress. Please try again.');
        }
      } finally {
        if (mounted) {
          setLoading(false);
        }
      }
    }

    if (user) {
      loadProgress();
    } else {
      setLoading(false);
    }

    return () => {
      mounted = false;
    };
  }, [user]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <LoadingSpinner size="lg" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <p className="text-red-500 mb-4">{error}</p>
          <button
            onClick={() => window.location.reload()}
            className="text-primary hover:underline"
          >
            Try Again
          </button>
        </div>
      </div>
    );
  }

  const getSubjectTitle = () => {
    switch (subject) {
      case 'mathematics':
        return 'Mathematics Quest';
      case 'english':
        return 'English Quest';
      default:
        return 'Learning Quest';
    }
  };

  const getSubjectDescription = () => {
    switch (subject) {
      case 'mathematics':
        return 'Embark on an exciting journey through numbers and problems';
      case 'english':
        return 'Explore the wonderful world of reading, writing, and language';
      default:
        return 'Begin your learning adventure';
    }
  };

  return (
    <div className="quests-page">
      <div className="container mx-auto px-4 py-8">
        <motion.button
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          onClick={() => navigate('/welcome-hero')}
          className="back-button"
        >
          <ArrowLeft className="h-5 w-5 mr-2" />
          Back to Home
        </motion.button>

        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="page-header"
        >
          <h1 className="page-title">{getSubjectTitle()}</h1>
          <p className="page-subtitle">
            {getSubjectDescription()}
          </p>
        </motion.div>

        {subject === 'mathematics' && <MathematicsHub />}
        {subject === 'english' && <EnglishHub />}
      </div>
    </div>
  );
}