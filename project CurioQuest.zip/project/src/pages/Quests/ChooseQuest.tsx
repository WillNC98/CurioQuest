import React from 'react';
import { Book, Calculator, Beaker, ArrowLeft } from 'lucide-react';
import { motion } from 'framer-motion';
import './Quests.css';

export function ChooseQuest() {
  const subjects = [
    {
      title: 'Maths',
      icon: <Calculator className="h-8 w-8" />,
      path: '/quests/maths',
      color: 'primary',
      description: 'Solve puzzles and unlock treasures with numbers!'
    },
    {
      title: 'English',
      icon: <Book className="h-8 w-8" />,
      path: '/quests/english',
      color: 'secondary',
      description: 'Embark on magical adventures with words!'
    },
    {
      title: 'Science',
      icon: <Beaker className="h-8 w-8" />,
      path: '/quests/science',
      color: 'accent',
      description: 'Discover the wonders of the world!'
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-b from-primary/5 to-secondary/5">
      <div className="container mx-auto px-4 py-12">
        <motion.button
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          onClick={() => window.location.href = '/welcome-hero'}
          className="mb-6 flex items-center text-neutral-600 hover:text-neutral-800"
        >
          <ArrowLeft className="h-5 w-5 mr-2" />
          Back to Home
        </motion.button>

        <motion.div 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-12"
        >
          <h1 className="text-4xl font-display font-bold text-neutral-800 mb-4">
            Choose Your Quest
          </h1>
          <p className="text-xl text-neutral-600">
            What would you like to learn today?
          </p>
        </motion.div>

        <div className="grid gap-6 md:grid-cols-3 max-w-4xl mx-auto">
          {subjects.map((subject, index) => (
            <motion.button
              key={subject.title}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 + index * 0.1 }}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => window.location.href = subject.path}
              className={`quest-card ${subject.color}`}
            >
              <div className="quest-icon-wrapper">
                {subject.icon}
              </div>
              <h2 className="text-2xl font-display font-bold mt-4 mb-2">
                {subject.title}
              </h2>
              <p className="text-neutral-600">
                {subject.description}
              </p>
            </motion.button>
          ))}
        </div>
      </div>
    </div>
  );
}