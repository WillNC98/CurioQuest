import React, { useState } from 'react';
import { Send, Image, ArrowLeft } from 'lucide-react';
import { motion } from 'framer-motion';
import './HomeworkWizard.css';

export function HomeworkWizard() {
  const [messages, setMessages] = useState<Array<{ text: string; isUser: boolean }>>([
    { text: "Hi! I'm your Homework Wizard. What would you like help with today?", isUser: false }
  ]);
  const [input, setInput] = useState('');

  const handleSend = () => {
    if (!input.trim()) return;
    
    setMessages(prev => [...prev, { text: input, isUser: true }]);
    setInput('');
    
    // Mock AI response
    setTimeout(() => {
      setMessages(prev => [...prev, {
        text: "I'll help you with that! Let's break it down step by step...",
        isUser: false
      }]);
    }, 1000);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-primary/5 to-secondary/5">
      <div className="container mx-auto px-4 py-6">
        <motion.button
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          onClick={() => window.location.href = '/welcome-hero'}
          className="mb-6 flex items-center text-neutral-600 hover:text-neutral-800"
        >
          <ArrowLeft className="h-5 w-5 mr-2" />
          Back to Home
        </motion.button>

        <div className="bg-white rounded-2xl shadow-xl max-w-2xl mx-auto overflow-hidden">
          <div className="p-6 bg-primary/10">
            <h1 className="text-2xl font-display font-bold text-neutral-800">
              Homework Wizard
            </h1>
          </div>

          <div className="h-[500px] overflow-y-auto p-6">
            {messages.map((message, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className={`mb-4 flex ${message.isUser ? 'justify-end' : 'justify-start'}`}
              >
                <div className={`message ${message.isUser ? 'user' : 'ai'}`}>
                  {message.text}
                </div>
              </motion.div>
            ))}
          </div>

          <div className="p-4 border-t border-neutral-200">
            <div className="flex gap-2">
              <button className="p-2 text-neutral-600 hover:text-neutral-800">
                <Image className="h-6 w-6" />
              </button>
              <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && handleSend()}
                placeholder="Ask me anything..."
                className="flex-1 px-4 py-2 rounded-xl border border-neutral-200 focus:border-primary focus:ring-1 focus:ring-primary"
              />
              <button
                onClick={handleSend}
                className="p-2 bg-primary text-white rounded-xl hover:bg-primary-dark"
              >
                <Send className="h-6 w-6" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}