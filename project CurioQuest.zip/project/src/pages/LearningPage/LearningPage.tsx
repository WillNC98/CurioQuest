import React from 'react';
import { HeaderComponent } from '../../components/layout/HeaderComponent/HeaderComponent';
import { ButtonComponent } from '../../components/common/ButtonComponent/ButtonComponent';
import { ProgressBar } from '../../components/learning/ProgressBar';
import { useProgress } from '../../hooks/useProgress';
import { Play } from 'lucide-react';
import './LearningPage.css';

export function LearningPage() {
  const progress = useProgress(60);

  return (
    <div className="min-h-screen">
      <HeaderComponent />
      <main className="container mx-auto px-4 py-8">
        <div className="course-header">
          <h1 className="text-3xl md:text-4xl font-display">Introduction to Science</h1>
          <p className="text-gray-600 mt-2">Discover the wonders of scientific exploration</p>
        </div>

        <div className="mt-8 grid gap-8 md:grid-cols-3">
          <div className="md:col-span-2">
            <div className="content-card">
              <h2 className="text-2xl font-display mb-4">Current Lesson</h2>
              <ProgressBar progress={progress} />
              <ButtonComponent 
                variant="primary"
                className="mt-4"
              >
                <Play className="h-5 w-5 mr-2" />
                Continue Learning
              </ButtonComponent>
            </div>
          </div>

          <div className="lessons-sidebar">
            <h3 className="text-xl font-display mb-4">Course Content</h3>
            <div className="lesson-list">
              {/* Lesson items will be dynamically rendered here */}
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}