import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Sword, Trophy, Target, Sparkles } from 'lucide-react';
import { motion } from 'framer-motion';
import { AskMeAnything } from '../../components/learning/AskMeAnything/AskMeAnything';
import './WelcomeHero.css';

export function WelcomeHero() {
  const navigate = useNavigate();
  
  const menuItems = [
    { icon: <Sword className="h-8 w-8" />, title: 'New Quests', path: '/quests', color: 'primary' },
    { icon: <Trophy className="h-8 w-8" />, title: 'Achievements', path: '/achievements', color: 'secondary' },
    { icon: <Target className="h-8 w-8" />, title: 'Daily Goals', path: '/goals', color: 'accent' },
    { icon: <Sparkles className="h-8 w-8" />, title: 'Homework Wizard', path: '/homework', color: 'primary' }
  ];

  return (
    <div className="welcome-hero">
      <div className="container mx-auto px-4 py-12">
        <div className="text-center mb-12">
          <motion.h1 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-4xl md:text-5xl font-display font-bold text-neutral-800 mb-4"
          >
            Welcome, Hero!
          </motion.h1>
          <motion.p 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.2 }}
            className="text-xl text-neutral-600"
          >
            Choose your next adventure
          </motion.p>
        </div>

        <motion.div 
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ delay: 0.4 }}
          className="flex justify-center mb-12"
        >
          <div className="avatar-container">
            <div className="avatar-circle">
              <span className="text-4xl">🦸‍♂️</span>
            </div>
            <div className="avatar-glow"></div>
          </div>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-2xl mx-auto">
          {menuItems.map((item, index) => (
            <motion.button
              key={index}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.6 + index * 0.1 }}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => navigate(item.path)}
              className={`menu-card group ${item.color}`}
            >
              <div className="icon-wrapper">
                {item.icon}
              </div>
              <h3 className="text-xl font-display font-semibold mt-4">
                {item.title}
              </h3>
            </motion.button>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="mt-12"
        >
          <AskMeAnything defaultComplexity={1} />
        </motion.div>
      </div>
    </div>
  );
}