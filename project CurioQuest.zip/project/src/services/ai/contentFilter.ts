// Age-appropriate word lists and topics
const INAPPROPRIATE_WORDS = [
  'violence',
  'explicit',
  'gore',
  'death',
  // Add more inappropriate words as needed
];

const AGE_GROUP_FILTERS = {
  1: [...INAPPROPRIATE_WORDS, 'complex', 'advanced', 'theoretical'],
  2: [...INAPPROPRIATE_WORDS],
  3: [...INAPPROPRIATE_WORDS.filter(word => word !== 'death')] // Older kids can handle some concepts
};

export function filterInappropriateContent(text: string, ageGroup: number = 1): boolean {
  const filters = AGE_GROUP_FILTERS[ageGroup as keyof typeof AGE_GROUP_FILTERS] || AGE_GROUP_FILTERS[1];
  const words = text.toLowerCase().split(/\s+/);
  
  return !words.some(word => filters.includes(word));
}

const COMPLEXITY_ADJUSTMENTS = {
  1: {
    maxSentenceLength: 10,
    maxWordLength: 6,
    simplifyTerms: new Map([
      ['difficult', 'hard'],
      ['approximately', 'about'],
      // Add more term simplifications
    ])
  },
  2: {
    maxSentenceLength: 15,
    maxWordLength: 8,
    simplifyTerms: new Map([
      ['approximately', 'about'],
      // Add more term simplifications
    ])
  },
  3: {
    maxSentenceLength: 20,
    maxWordLength: 10,
    simplifyTerms: new Map()
  }
};

export function adjustComplexityForAge(text: string, ageGroup: number): string {
  const settings = COMPLEXITY_ADJUSTMENTS[ageGroup as keyof typeof COMPLEXITY_ADJUSTMENTS] || COMPLEXITY_ADJUSTMENTS[1];
  
  let adjustedText = text;
  
  // Simplify terms
  settings.simplifyTerms.forEach((simple, complex) => {
    adjustedText = adjustedText.replace(new RegExp(complex, 'gi'), simple);
  });
  
  // Split into sentences and adjust length
  const sentences = adjustedText.match(/[^.!?]+[.!?]+/g) || [];
  adjustedText = sentences
    .map(sentence => {
      const words = sentence.trim().split(/\s+/);
      if (words.length > settings.maxSentenceLength) {
        return words.slice(0, settings.maxSentenceLength).join(' ') + '.';
      }
      return sentence;
    })
    .join(' ');
  
  return adjustedText;
}