export interface GenerateContentOptions {
  maxTokens?: number;
  temperature?: number;
  complexity?: number;
  responseType?: 'text' | 'video' | 'quiz';
  responseLength?: 'short' | 'medium' | 'long';
}

export interface AIResponse {
  content: string;
  error?: string;
}

export interface AIError extends Error {
  code?: string;
  status?: number;
}