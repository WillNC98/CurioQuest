export const AI_CONFIG = {
  model: "gpt-3.5-turbo",
  defaultMaxTokens: 500,
  defaultTemperature: 0.7,
  systemPrompt: "You are a helpful educational assistant that creates engaging learning content."
} as const;

export function getOpenAIConfig() {
  const apiKey = import.meta.env.VITE_OPENAI_API_KEY;
  
  if (!apiKey) {
    throw new Error('OpenAI API key not found in environment variables');
  }
  
  return { apiKey };
}