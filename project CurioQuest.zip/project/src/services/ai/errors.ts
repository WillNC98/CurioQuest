export class AIServiceError extends Error {
  constructor(
    message: string,
    public code?: string,
    public status?: number
  ) {
    super(message);
    this.name = 'AIServiceError';
  }

  static fromOpenAIError(error: any): AIServiceError {
    // Handle quota exceeded error
    if (error.error?.code === 'insufficient_quota') {
      return new AIServiceError(
        'API quota exceeded. Please check your OpenAI account billing details.',
        'QUOTA_EXCEEDED',
        429
      );
    }

    // Handle rate limiting
    if (error.status === 429) {
      return new AIServiceError(
        'Too many requests. Please try again later.',
        'RATE_LIMITED',
        429
      );
    }

    // Handle authentication errors
    if (error.status === 401) {
      return new AIServiceError(
        'Invalid API key. Please check your configuration.',
        'INVALID_API_KEY',
        401
      );
    }

    // Generic error handling
    return new AIServiceError(
      error.error?.message || 'An unexpected error occurred',
      error.error?.code,
      error.status
    );
  }
}