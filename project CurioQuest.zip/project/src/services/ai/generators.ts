import { openai } from './client';
import { AI_CONFIG } from './config';
import { AIResponse, GenerateContentOptions } from './types';
import { AIServiceError } from './errors';
import { filterInappropriateContent } from './contentFilter';

export async function generateLearningContent(
  prompt: string,
  options: GenerateContentOptions = {}
): Promise<AIResponse> {
  // Check for inappropriate content
  if (!filterInappropriateContent(prompt)) {
    throw new AIServiceError('Inappropriate content detected', 'INAPPROPRIATE_CONTENT');
  }

  try {
    const response = await openai.chat.completions.create({
      model: AI_CONFIG.model,
      messages: [
        { 
          role: "system", 
          content: `You are a helpful educational assistant for children. 
                   Adjust your language for ${options.complexity || 1} complexity level.
                   Provide ${options.responseLength || 'medium'} length responses.
                   Format as ${options.responseType || 'text'}.`
        },
        { role: "user", content: prompt }
      ],
      temperature: options.temperature ?? AI_CONFIG.defaultTemperature,
      max_tokens: options.maxTokens ?? AI_CONFIG.defaultMaxTokens
    });

    const content = response.choices[0]?.message?.content;
    if (!content) {
      throw new AIServiceError('No content generated', 'NO_CONTENT');
    }

    return { content };
  } catch (error: any) {
    console.error('AI generation error:', error);
    throw AIServiceError.fromOpenAIError(error);
  }
}