import OpenAI from 'openai';
import { getOpenAIConfig } from './config';

const apiKey = import.meta.env.VITE_OPENAI_API_KEY;

if (!apiKey) {
  console.warn('OpenAI API key not found. AI features will be mocked in development.');
}

export const openai = new OpenAI({
  apiKey: apiKey || 'mock-key',
  dangerouslyAllowBrowser: true
});