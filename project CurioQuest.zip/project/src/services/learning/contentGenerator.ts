import { generateLearningContent } from '../ai/generators';
import { Activity, ComprehensionLevel } from '../../types/learning';

interface GenerateContentParams {
  topic: string;
  subtopic: string;
  level: ComprehensionLevel;
  type: Activity['type'];
}

export async function generateActivityContent({
  topic,
  subtopic,
  level,
  type
}: GenerateContentParams): Promise<string> {
  const prompts: Record<Activity['type'], string> = {
    lesson: `Create an engaging ${level} level lesson about ${subtopic} in ${topic}. 
            The content should be child-friendly and include examples.`,
    quiz: `Generate a ${level} difficulty quiz about ${subtopic} in ${topic}. 
          Include 5 multiple-choice questions with answers.`,
    game: `Design a simple educational game concept for teaching ${subtopic} in ${topic} 
          at a ${level} level. Include clear instructions and learning objectives.`
  };

  const response = await generateLearningContent(prompts[type]);
  return response.content;
}