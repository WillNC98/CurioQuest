import { ActivityType, ActivityCompletion } from '../../types/learning';

const EXPERIENCE_POINTS = {
  lesson: 10,
  quiz: 20,
  game: 15
} as const;

const LEVEL_THRESHOLDS = [0, 100, 250, 450, 700, 1000, 1350, 1750, 2200, 2700];

export function calculateExperience(type: ActivityType, performance: number = 1): number {
  const basePoints = EXPERIENCE_POINTS[type];
  return Math.round(basePoints * performance);
}

export function calculateLevel(experiencePoints: number): number {
  return LEVEL_THRESHOLDS.findIndex(threshold => experiencePoints < threshold) - 1;
}

export function getNextLevelThreshold(currentLevel: number): number {
  return LEVEL_THRESHOLDS[currentLevel + 1] || Infinity;
}

export function getExperienceProgress(experiencePoints: number): number {
  const currentLevel = calculateLevel(experiencePoints);
  const currentThreshold = LEVEL_THRESHOLDS[currentLevel];
  const nextThreshold = LEVEL_THRESHOLDS[currentLevel + 1];
  
  return ((experiencePoints - currentThreshold) / (nextThreshold - currentThreshold)) * 100;
}