import { Topic, ComprehensionLevel } from '../../types/learning';
import { db } from '../../config/firebase';
import { collection, doc, getDoc, getDocs, query, where } from 'firebase/firestore';

const TOPICS_COLLECTION = 'topics';

export async function getTopicsByBranch(branch: string): Promise<Topic[]> {
  const topicsRef = collection(db, TOPICS_COLLECTION);
  const q = query(topicsRef, where('branch', '==', branch));
  const snapshot = await getDocs(q);
  
  return snapshot.docs.map(doc => ({
    id: doc.id,
    ...doc.data()
  } as Topic));
}

export async function getTopic(topicId: string): Promise<Topic | null> {
  const topicRef = doc(db, TOPICS_COLLECTION, topicId);
  const topicSnap = await getDoc(topicRef);
  
  return topicSnap.exists() ? {
    id: topicSnap.id,
    ...topicSnap.data()
  } as Topic : null;
}

export async function getRecommendedTopics(
  userLevel: ComprehensionLevel,
  completedTopics: string[]
): Promise<Topic[]> {
  const topicsRef = collection(db, TOPICS_COLLECTION);
  const q = query(
    topicsRef,
    where('requiredLevel', '<=', userLevel)
  );
  
  const snapshot = await getDocs(q);
  return snapshot.docs
    .map(doc => ({
      id: doc.id,
      ...doc.data()
    } as Topic))
    .filter(topic => !completedTopics.includes(topic.id));
}