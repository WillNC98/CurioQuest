import { doc, getDoc, setDoc, updateDoc, arrayUnion } from 'firebase/firestore';
import { db } from '../../config/firebase';
import { enableIndexedDbPersistence } from 'firebase/firestore';

// Enable offline persistence with proper error handling
try {
  enableIndexedDbPersistence(db).catch((err) => {
    if (err.code === 'failed-precondition') {
      // Multiple tabs open, persistence can only be enabled in one tab at a time
      console.warn('Multiple tabs open, persistence enabled in another tab');
    } else if (err.code === 'unimplemented') {
      // The current browser doesn't support persistence
      console.warn('Browser does not support persistence');
    }
  });
} catch (error) {
  console.warn('Error enabling persistence:', error);
}

// In-memory fallback for offline scenarios
const offlineProgress = new Map<string, UserProgress>();

interface UserProgress {
  completedLevels: string[];
  lastUpdated: string;
}

export async function fetchUserProgress(userId: string): Promise<UserProgress> {
  if (!userId) {
    throw new Error('User ID is required');
  }

  // Check memory cache first
  const cachedProgress = offlineProgress.get(userId);
  if (cachedProgress) {
    return cachedProgress;
  }

  try {
    const progressRef = doc(db, 'userProgress', userId);
    const progressDoc = await getDoc(progressRef);

    if (!progressDoc.exists()) {
      const initialProgress: UserProgress = {
        completedLevels: [],
        lastUpdated: new Date().toISOString()
      };
      
      try {
        await setDoc(progressRef, initialProgress);
        offlineProgress.set(userId, initialProgress);
      } catch (error) {
        console.warn('Failed to create initial progress, using memory fallback');
      }
      
      return initialProgress;
    }

    const progress = progressDoc.data() as UserProgress;
    offlineProgress.set(userId, progress);
    return progress;
  } catch (error) {
    console.warn('Error fetching progress, using memory fallback:', error);
    // Return cached progress or create new one
    const fallbackProgress: UserProgress = cachedProgress || {
      completedLevels: [],
      lastUpdated: new Date().toISOString()
    };
    offlineProgress.set(userId, fallbackProgress);
    return fallbackProgress;
  }
}

export async function updateUserProgress(userId: string, levelId: string): Promise<void> {
  if (!userId) {
    throw new Error('User ID is required');
  }

  // Update memory cache first
  const currentProgress = offlineProgress.get(userId) || {
    completedLevels: [],
    lastUpdated: new Date().toISOString()
  };
  
  if (!currentProgress.completedLevels.includes(levelId)) {
    currentProgress.completedLevels.push(levelId);
    currentProgress.lastUpdated = new Date().toISOString();
    offlineProgress.set(userId, currentProgress);
  }

  try {
    const progressRef = doc(db, 'userProgress', userId);
    await updateDoc(progressRef, {
      completedLevels: arrayUnion(levelId),
      lastUpdated: new Date().toISOString()
    });
  } catch (error) {
    console.warn('Failed to update progress in Firestore:', error);
    // Continue with cached version
  }
}