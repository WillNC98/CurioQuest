export function getNetworkError(error: any): string {
  if (error.code === 'auth/network-request-failed') {
    return navigator.onLine 
      ? 'Unable to connect to authentication server. Please try again.'
      : 'No internet connection. Please check your network and try again.';
  }
  return error.message;
}