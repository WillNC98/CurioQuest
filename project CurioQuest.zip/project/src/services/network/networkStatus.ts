// Simple network status manager without external dependencies
class NetworkStatusManager {
  private listeners: Set<(online: boolean) => void> = new Set();
  private _isOnline: boolean;

  constructor() {
    this._isOnline = navigator.onLine;
    window.addEventListener('online', () => this.updateStatus(true));
    window.addEventListener('offline', () => this.updateStatus(false));
  }

  private updateStatus(status: boolean) {
    this._isOnline = status;
    this.notifyListeners();
  }

  private notifyListeners() {
    this.listeners.forEach(listener => listener(this._isOnline));
  }

  public subscribe(listener: (online: boolean) => void) {
    this.listeners.add(listener);
    // Initial status
    listener(this._isOnline);
    // Return unsubscribe function
    return () => this.listeners.delete(listener);
  }

  public isOnline(): boolean {
    return this._isOnline && window.navigator.onLine;
  }

  public waitForConnection(): Promise<void> {
    if (this.isOnline()) {
      return Promise.resolve();
    }

    return new Promise(resolve => {
      const handler = (online: boolean) => {
        if (online) {
          this.listeners.delete(handler);
          resolve();
        }
      };
      this.listeners.add(handler);
    });
  }
}

// Export singleton instance
export const networkStatus = new NetworkStatusManager();