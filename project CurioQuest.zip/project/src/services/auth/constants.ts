export const AUTH_CONFIG = {
  ADMIN_CREDENTIALS: {
    email: 'admin@curioquest.com',
    password: 'CQ_Admin_2024!'
  }
} as const;