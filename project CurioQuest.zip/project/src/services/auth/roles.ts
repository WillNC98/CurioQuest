import { User } from 'firebase/auth';
import { doc, getDoc } from 'firebase/firestore';
import { db } from '../../config/firebase';

export type UserRole = 'user' | 'admin';

export async function getUserRole(user: User): Promise<UserRole> {
  const userDoc = await getDoc(doc(db, 'users', user.uid));
  return userDoc.exists() ? (userDoc.data().role as UserRole) : 'user';
}