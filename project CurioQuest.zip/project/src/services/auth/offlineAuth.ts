import { AUTH_CONFIG } from './constants';

interface AdminData {
  email: string;
  role: 'admin';
  uid: string;
}

export function validateOfflineCredentials(email: string, password: string): { userData: AdminData } | null {
  if (email === AUTH_CONFIG.ADMIN_CREDENTIALS.email && 
      password === AUTH_CONFIG.ADMIN_CREDENTIALS.password) {
    return {
      userData: {
        email: AUTH_CONFIG.ADMIN_CREDENTIALS.email,
        role: 'admin',
        uid: 'admin-offline'
      }
    };
  }
  return null;
}

export function storeCredentials(email: string, password: string): void {
  localStorage.setItem('adminCredentials', JSON.stringify({ email, password }));
}

export function getOfflineUserData(): AdminData | null {
  const stored = localStorage.getItem('adminCredentials');
  if (!stored) return null;

  const { email } = JSON.parse(stored);
  if (email === AUTH_CONFIG.ADMIN_CREDENTIALS.email) {
    return {
      email,
      role: 'admin',
      uid: 'admin-offline'
    };
  }
  return null;
}

export function clearStoredCredentials(): void {
  localStorage.removeItem('adminCredentials');
}