import { BehaviorSubject } from 'rxjs';

// Network status observable
export const networkStatus$ = new BehaviorSubject<boolean>(navigator.onLine);

// Network status listeners
window.addEventListener('online', () => networkStatus$.next(true));
window.addEventListener('offline', () => networkStatus$.next(false));

export function isOnline(): boolean {
  return networkStatus$.getValue();
}

export function getNetworkError(error: any): string {
  if (error.code === 'auth/network-request-failed') {
    return isOnline() 
      ? 'Unable to connect to authentication server. Please try again.'
      : 'No internet connection. Please check your network and try again.';
  }
  return error.message;
}