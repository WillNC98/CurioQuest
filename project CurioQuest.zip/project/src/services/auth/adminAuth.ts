import { auth } from '../../config/firebase';
import { signInWithEmailAndPassword } from 'firebase/auth';
import { networkStatus } from '../network/networkStatus';
import { getNetworkError } from '../network/errors';
import { ENV } from '../../config/env';

// Use environment variables for admin credentials
const ADMIN_CREDENTIALS = {
  email: ENV.ADMIN.EMAIL,
  password: ENV.ADMIN.PASSWORD
};

export async function autoLoginAdmin() {
  // Check stored credentials first
  const stored = localStorage.getItem('adminCredentials');
  if (stored) {
    return JSON.parse(stored);
  }

  if (!networkStatus.isOnline()) {
    throw new Error('No internet connection and no stored credentials found.');
  }

  try {
    const userCredential = await signInWithEmailAndPassword(
      auth,
      ADMIN_CREDENTIALS.email,
      ADMIN_CREDENTIALS.password
    );

    const adminData = {
      user: {
        uid: userCredential.user.uid,
        email: userCredential.user.email,
        role: 'admin'
      },
      credentials: ADMIN_CREDENTIALS
    };
    
    localStorage.setItem('adminCredentials', JSON.stringify(adminData));
    return adminData;
  } catch (error: any) {
    console.error('Auto-login failed:', error);
    throw new Error(getNetworkError(error));
  }
}