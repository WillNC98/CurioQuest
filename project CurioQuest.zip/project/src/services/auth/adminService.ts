import { doc, setDoc } from 'firebase/firestore';
import { db } from '../../config/firebase';
import { auth } from '../../config/firebase';
import { createUserWithEmailAndPassword } from 'firebase/auth';

export async function createAdminAccount(email: string, password: string) {
  try {
    // Create the user account
    const userCredential = await createUserWithEmailAndPassword(auth, email, password);
    
    // Set admin role in Firestore
    await setDoc(doc(db, 'users', userCredential.user.uid), {
      role: 'admin',
      email,
      createdAt: new Date().toISOString()
    });

    return userCredential.user;
  } catch (error) {
    console.error('Error creating admin account:', error);
    throw error;
  }
}