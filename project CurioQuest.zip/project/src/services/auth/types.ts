import { AuthUser, AuthError } from '../../types/auth';

export interface AuthResponse {
  user: AuthUser;
  token: string;
}

export interface SignInCredentials {
  email: string;
  password: string;
}

export interface SignUpCredentials extends SignInCredentials {
  displayName?: string;
}