import { User } from 'firebase/auth';
import { mockUser } from './mockAuth';

const isDev = import.meta.env.DEV;

export async function signIn(email: string, password: string): Promise<User> {
  if (isDev) {
    return mockUser;
  }
  throw new Error('Authentication not available in development mode');
}

export async function signUp(email: string, password: string): Promise<User> {
  if (isDev) {
    return mockUser;
  }
  throw new Error('Authentication not available in development mode');
}

export async function signOut(): Promise<void> {
  if (isDev) {
    return;
  }
  throw new Error('Authentication not available in development mode');
}

export function onAuthChange(callback: (user: User | null) => void): () => void {
  if (isDev) {
    // Simulate an authenticated user in development
    setTimeout(() => callback(mockUser), 100);
    return () => {};
  }
  return () => {};
}