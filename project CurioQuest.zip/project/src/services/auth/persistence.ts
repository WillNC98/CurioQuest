import { auth } from '../../config/firebase';
import { browserLocalPersistence, setPersistence } from 'firebase/auth';

export async function enableAuthPersistence() {
  try {
    await setPersistence(auth, browserLocalPersistence);
    console.log('Auth persistence enabled');
  } catch (error) {
    console.error('Error enabling auth persistence:', error);
  }
}