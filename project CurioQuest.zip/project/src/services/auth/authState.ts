import { AuthState } from './types';

let authState: AuthState = {
  user: null,
  isAuthenticated: false,
  token: localStorage.getItem('auth_token'),
};

export function getAuthState(): AuthState {
  return { ...authState };
}

export function setAuthState(newState: Partial<AuthState>) {
  authState = { ...authState, ...newState };
  
  if (newState.token) {
    localStorage.setItem('auth_token', newState.token);
  } else if (newState.token === null) {
    localStorage.removeItem('auth_token');
  }
}

export function clearAuth() {
  setAuthState({
    user: null,
    isAuthenticated: false,
    token: null,
  });
}