/**
 * Authentication service
 */
import { AuthState, User } from './types';
import { getAuthState, setAuthState, clearAuth } from './authState';

export const auth = {
  getState: getAuthState,
  setState: setAuthState,
  clear: clearAuth,
};