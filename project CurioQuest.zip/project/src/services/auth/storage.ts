import { AUTH_STORAGE_KEY } from './constants';

interface StoredAuth {
  user: {
    uid: string;
    email: string | null;
    role: string;
  };
  credentials: {
    email: string;
    password: string;
  };
}

export function storeAuthCredentials(data: StoredAuth): void {
  try {
    localStorage.setItem(AUTH_STORAGE_KEY, JSON.stringify(data));
  } catch (error) {
    console.error('Failed to store auth credentials:', error);
  }
}

export function getStoredCredentials(): StoredAuth | null {
  try {
    const stored = localStorage.getItem(AUTH_STORAGE_KEY);
    return stored ? JSON.parse(stored) : null;
  } catch (error) {
    console.error('Failed to retrieve stored credentials:', error);
    return null;
  }
}

export function clearStoredCredentials(): void {
  localStorage.removeItem(AUTH_STORAGE_KEY);
}