import { doc, setDoc, getDoc, updateDoc } from 'firebase/firestore';
import { db } from '../../config/firebase';
import { User } from '../../types/api';

const isDev = import.meta.env.DEV;

export async function createUserProfile(userId: string, userData: Partial<User>): Promise<void> {
  if (isDev) {
    console.log('Development mode: Mocking createUserProfile');
    return;
  }

  try {
    const userRef = doc(db, 'users', userId);
    await setDoc(userRef, {
      ...userData,
      createdAt: new Date().toISOString()
    });
  } catch (error) {
    console.error('Error creating user profile:', error);
    throw new Error('Failed to create user profile. Please try again.');
  }
}

export async function getUserProfile(userId: string): Promise<User | null> {
  if (isDev) {
    console.log('Development mode: Returning mock user profile');
    return {
      id: userId,
      email: 'test@example.com',
      name: 'Test User',
      progress: 50
    };
  }

  try {
    const userRef = doc(db, 'users', userId);
    const userSnap = await getDoc(userRef);
    
    if (!userSnap.exists()) {
      return null;
    }
    
    return {
      id: userSnap.id,
      ...userSnap.data() as Omit<User, 'id'>
    };
  } catch (error) {
    console.error('Error fetching user profile:', error);
    throw new Error('Failed to fetch user profile. Please check your connection.');
  }
}

export async function updateUserProfile(userId: string, updates: Partial<User>): Promise<void> {
  if (isDev) {
    console.log('Development mode: Mocking updateUserProfile');
    return;
  }

  try {
    const userRef = doc(db, 'users', userId);
    await updateDoc(userRef, {
      ...updates,
      updatedAt: new Date().toISOString()
    });
  } catch (error) {
    console.error('Error updating user profile:', error);
    throw new Error('Failed to update user profile. Please try again.');
  }
}