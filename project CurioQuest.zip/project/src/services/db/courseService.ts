import { collection, doc, getDoc, getDocs, query, where, addDoc, updateDoc } from 'firebase/firestore';
import { db } from '../../config/firebase';
import { Course } from '../../types/api';
import { CourseData } from './types';

const COURSES_COLLECTION = 'courses';

export async function getCourse(courseId: string): Promise<Course | null> {
  const courseRef = doc(db, COURSES_COLLECTION, courseId);
  const courseSnap = await getDoc(courseRef);
  return courseSnap.exists() ? { id: courseSnap.id, ...courseSnap.data() as CourseData } : null;
}

export async function getUserCourses(userId: string): Promise<Course[]> {
  const coursesRef = collection(db, COURSES_COLLECTION);
  const q = query(coursesRef, where('authorId', '==', userId));
  const querySnapshot = await getDocs(q);
  
  return querySnapshot.docs.map(doc => ({
    id: doc.id,
    ...doc.data() as CourseData
  }));
}

export async function createCourse(courseData: CourseData): Promise<string> {
  const coursesRef = collection(db, COURSES_COLLECTION);
  const docRef = await addDoc(coursesRef, {
    ...courseData,
    createdAt: new Date().toISOString()
  });
  return docRef.id;
}

export async function updateCourse(courseId: string, updates: Partial<CourseData>): Promise<void> {
  const courseRef = doc(db, COURSES_COLLECTION, courseId);
  await updateDoc(courseRef, {
    ...updates,
    updatedAt: new Date().toISOString()
  });
}