import { User, Course, Lesson } from '../../types/api';

export interface CreateUserData extends Omit<User, 'id'> {
  createdAt?: string;
}

export interface UpdateUserData extends Partial<User> {
  updatedAt?: string;
}

export interface CourseData extends Omit<Course, 'id'> {
  authorId: string;
  createdAt: string;
  updatedAt?: string;
}

export interface LessonData extends Omit<Lesson, 'id'> {
  courseId: string;
  order: number;
  content: string;
}