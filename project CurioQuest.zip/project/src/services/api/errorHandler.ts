/**
 * Centralized error handling for API requests
 */
export function handleError(error: unknown): never {
  if (error instanceof Error) {
    // Log error to monitoring service
    console.error('API Error:', error.message);
    
    // Handle specific error types
    if (error.message.includes('401')) {
      throw new Error('Authentication required');
    }
    
    if (error.message.includes('403')) {
      throw new Error('Access denied');
    }
  }
  
  throw error;
}