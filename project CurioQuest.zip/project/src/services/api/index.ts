/**
 * API service configuration and base setup
 */
import { fetchApi } from './fetchApi';
import { handleError } from './errorHandler';

export const api = {
  fetch: fetchApi,
  handleError,
};