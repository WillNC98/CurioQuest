// English curriculum structure for Key Stage 1
export const englishCurriculum = {
  id: 'key-stage-1',
  title: 'Key Stage 1',
  ageRange: '5-7',
  description: 'Foundation English skills including phonics, reading, writing, and grammar.',
  topics: [
    {
      id: 'reading-phonics',
      title: 'Reading and Phonics',
      subtopics: [
        {
          id: 'sight-words',
          title: 'Sight Words',
          description: 'Learn common sight words for improved reading fluency.',
          lessons: [
            {
              id: 'intro-sight-words',
              title: 'Introduction to Sight Words',
              type: 'lesson',
              ageRange: '5-6',
              content: 'Learn common sight words through word-image matching.'
            },
            {
              id: 'sight-word-practice',
              title: 'Sight Word Practice',
              type: 'lesson',
              ageRange: '5-6',
              content: 'Build simple sentences using sight words.'
            },
            {
              id: 'advanced-sight-words',
              title: 'Advanced Sight Words',
              type: 'lesson',
              ageRange: '6-7',
              content: 'Practice less common sight words with flashcards.'
            },
            {
              id: 'sight-word-quiz-1',
              title: 'Identify Sight Words',
              type: 'quiz',
              ageRange: '5-7',
              content: 'Can you identify sight words in short sentences?'
            },
            {
              id: 'sight-word-quiz-2',
              title: 'Fill in the Blanks',
              type: 'quiz',
              ageRange: '5-7',
              content: 'Complete sentences using sight words.'
            },
            {
              id: 'sight-word-memory',
              title: 'Sight Word Memory Match',
              type: 'game',
              ageRange: '5-6',
              content: 'Match pairs of sight words in this memory game.'
            },
            {
              id: 'sight-word-treasure',
              title: 'Sight Word Treasure Hunt',
              type: 'game',
              ageRange: '5-7',
              content: 'Find hidden sight words in exciting scenes.'
            },
            {
              id: 'word-maze',
              title: 'Word Maze Challenge',
              type: 'game',
              ageRange: '6-7',
              content: 'Navigate through mazes by following sight words.'
            }
          ]
        },
        {
          id: 'phonics',
          title: 'Phonics',
          description: 'Master basic phonics to build a strong foundation in reading.',
          lessons: [
            {
              id: 'blending-sounds',
              title: 'Blending Sounds',
              type: 'lesson',
              ageRange: '5-6',
              content: 'Learn to blend phonemes to form simple words.'
            },
            {
              id: 'segmenting-words',
              title: 'Segmenting Words',
              type: 'lesson',
              ageRange: '5-6',
              content: 'Practice breaking down words into individual sounds.'
            },
            {
              id: 'advanced-phonics',
              title: 'Advanced Phonics Activities',
              type: 'lesson',
              ageRange: '6-7',
              content: 'Apply phonics skills to longer and more complex words.'
            },
            {
              id: 'phonics-quiz-1',
              title: 'Sound Match Quiz',
              type: 'quiz',
              ageRange: '5-7',
              content: 'Which word does this sound make?'
            },
            {
              id: 'phonics-quiz-2',
              title: 'Word Sounds Quiz',
              type: 'quiz',
              ageRange: '5-7',
              content: 'Match sounds to words.'
            },
            {
              id: 'phonics-puzzle',
              title: 'Phonics Puzzle',
              type: 'game',
              ageRange: '5-6',
              content: 'Complete puzzles by matching sounds to pictures.'
            },
            {
              id: 'sound-slicer',
              title: 'Sound Slicer',
              type: 'game',
              ageRange: '6-7',
              content: 'Slice words into their individual sounds.'
            },
            {
              id: 'phonics-race',
              title: 'Phonics Speed Race',
              type: 'game',
              ageRange: '6-7',
              content: 'Race against time to blend sounds into words.'
            }
          ]
        }
      ]
    },
    {
      id: 'writing',
      title: 'Writing',
      subtopics: [
        {
          id: 'sentence-formation',
          title: 'Sentence Formation',
          description: 'Learn to construct clear and complete sentences.',
          lessons: [
            {
              id: 'simple-sentences',
              title: 'Writing Simple Sentences',
              type: 'lesson',
              ageRange: '5-6',
              content: 'Learn how to construct basic sentences with a subject and verb.'
            },
            {
              id: 'punctuation-basics',
              title: 'Punctuation Basics',
              type: 'lesson',
              ageRange: '5-6',
              content: 'Learn about full stops, question marks, and exclamation marks.'
            },
            {
              id: 'expanding-sentences',
              title: 'Expanding Sentences',
              type: 'lesson',
              ageRange: '6-7',
              content: 'Add adjectives and details to make sentences more interesting.'
            },
            {
              id: 'sentence-quiz-1',
              title: 'Sentence Structure Quiz',
              type: 'quiz',
              ageRange: '5-7',
              content: 'Identify correct sentence structures.'
            },
            {
              id: 'punctuation-quiz',
              title: 'Add the Punctuation',
              type: 'quiz',
              ageRange: '5-7',
              content: 'Choose the correct punctuation for each sentence.'
            },
            {
              id: 'sentence-builder',
              title: 'Sentence Builder',
              type: 'game',
              ageRange: '5-6',
              content: 'Build sentences by arranging words in the correct order.'
            },
            {
              id: 'punctuation-pop',
              title: 'Punctuation Pop',
              type: 'game',
              ageRange: '5-7',
              content: 'Pop balloons with the correct punctuation mark.'
            },
            {
              id: 'sentence-scramble',
              title: 'Sentence Scramble',
              type: 'game',
              ageRange: '6-7',
              content: 'Unscramble words to form correct sentences.'
            }
          ]
        },
        {
          id: 'creative-writing',
          title: 'Creative Writing',
          description: 'Express ideas through creative storytelling.',
          lessons: [
            {
              id: 'story-starters',
              title: 'Using Story Starters',
              type: 'lesson',
              ageRange: '5-6',
              content: 'Learn how to begin stories using creative prompts.'
            },
            {
              id: 'picture-prompts',
              title: 'Writing with Picture Prompts',
              type: 'lesson',
              ageRange: '6-7',
              content: 'Create stories inspired by interesting pictures.'
            },
            {
              id: 'story-order-quiz',
              title: 'Story Order Quiz',
              type: 'quiz',
              ageRange: '5-7',
              content: 'Put story events in the correct order.'
            },
            {
              id: 'description-quiz',
              title: 'Best Description Quiz',
              type: 'quiz',
              ageRange: '5-7',
              content: 'Choose the best description for a picture.'
            },
            {
              id: 'story-puzzle',
              title: 'Story Puzzle Adventure',
              type: 'game',
              ageRange: '5-6',
              content: 'Complete story puzzles by arranging events in order.'
            },
            {
              id: 'picture-story',
              title: 'Picture Story Builder',
              type: 'game',
              ageRange: '6-7',
              content: 'Create stories using a series of pictures.'
            }
          ]
        }
      ]
    },
    {
      id: 'grammar',
      title: 'Grammar',
      subtopics: [
        {
          id: 'nouns-verbs',
          title: 'Nouns and Verbs',
          description: 'Learn about naming words and action words.',
          lessons: [
            {
              id: 'identifying-nouns',
              title: 'Identifying Nouns',
              type: 'lesson',
              ageRange: '5-6',
              content: 'Learn how to recognize and categorize different types of nouns.'
            },
            {
              id: 'using-verbs',
              title: 'Using Verbs in Sentences',
              type: 'lesson',
              ageRange: '6-7',
              content: 'Discover how verbs show actions and make sentences come alive.'
            },
            {
              id: 'noun-quiz',
              title: 'Find the Nouns',
              type: 'quiz',
              ageRange: '5-7',
              content: 'Can you identify all the nouns in these sentences?'
            },
            {
              id: 'verb-quiz',
              title: 'Action Word Match',
              type: 'quiz',
              ageRange: '5-7',
              content: 'Match the verb to the correct action picture.'
            },
            {
              id: 'noun-explorer',
              title: 'Noun Explorer',
              type: 'game',
              ageRange: '5-6',
              content: 'Explore an interactive scene to find and collect nouns.'
            },
            {
              id: 'verb-action-race',
              title: 'Verb Action Race',
              type: 'game',
              ageRange: '6-7',
              content: 'Race against time to match verbs with animated actions.'
            }
          ]
        },
        {
          id: 'adjectives',
          title: 'Adjectives',
          description: 'Discover words that describe and add detail.',
          lessons: [
            {
              id: 'understanding-adjectives',
              title: 'Understanding Adjectives',
              type: 'lesson',
              ageRange: '5-6',
              content: 'Learn how adjectives describe nouns and make writing more interesting.'
            },
            {
              id: 'descriptive-writing',
              title: 'Using Adjectives in Descriptive Writing',
              type: 'lesson',
              ageRange: '6-7',
              content: 'Practice writing detailed sentences using descriptive adjectives.'
            },
            {
              id: 'adjective-quiz-1',
              title: 'Complete the Sentence',
              type: 'quiz',
              ageRange: '5-7',
              content: 'Choose the best adjective to complete each sentence.'
            },
            {
              id: 'adjective-quiz-2',
              title: 'Match the Descriptions',
              type: 'quiz',
              ageRange: '5-7',
              content: 'Match adjectives to the things they describe.'
            },
            {
              id: 'adjective-hunt',
              title: 'Adjective Hunt',
              type: 'game',
              ageRange: '5-6',
              content: 'Find hidden adjectives in an exciting story adventure.'
            },
            {
              id: 'adjective-match-up',
              title: 'Adjective Match-Up',
              type: 'game',
              ageRange: '6-7',
              content: 'Match descriptive words to objects in a colorful scene.'
            }
          ]
        },
        {
          id: 'sentence-building',
          title: 'Sentence Building with Grammar',
          description: 'Learn to combine different types of words to create complete sentences.',
          lessons: [
            {
              id: 'combining-words',
              title: 'Combining Nouns, Verbs, and Adjectives',
              type: 'lesson',
              ageRange: '6-7',
              content: 'Learn how to build detailed sentences using different types of words.'
            },
            {
              id: 'word-types-quiz',
              title: 'Identify Word Types',
              type: 'quiz',
              ageRange: '5-7',
              content: 'Can you identify nouns, verbs, and adjectives in sentences?'
            },
            {
              id: 'sentence-order-quiz',
              title: 'Sentence Order',
              type: 'quiz',
              ageRange: '6-7',
              content: 'Put words in the correct order to make proper sentences.'
            },
            {
              id: 'grammar-builder',
              title: 'Grammar Builder',
              type: 'game',
              ageRange: '5-7',
              content: 'Create sentences by dragging and dropping different types of words.'
            },
            {
              id: 'sentence-detective',
              title: 'Sentence Detective',
              type: 'game',
              ageRange: '6-7',
              content: 'Find the missing parts of speech to solve sentence mysteries.'
            }
          ]
        }
      ]
    }
  ]
};