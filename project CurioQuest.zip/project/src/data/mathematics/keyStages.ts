import { KeyStageContent } from './types';

export const keyStages: Record<string, KeyStageContent> = {
  'key-stage-1': {
    id: 'key-stage-1',
    title: 'Key Stage 1',
    ageRange: '5-7',
    description: 'Foundation mathematics skills including counting, basic operations, and shapes.',
    topics: [
      {
        id: 'number',
        title: 'Number',
        subtopics: [
          {
            id: 'counting',
            title: 'Counting and Place Value',
            description: 'Learn to count, read, write, and understand numbers up to 100.',
            lessons: [
              { id: 'counting-1-20', title: 'Counting to 20', ageRange: '5-6' },
              { id: 'counting-50', title: 'Counting to 50', ageRange: '5-6' },
              { id: 'counting-100', title: 'Counting to 100', ageRange: '6-7' },
              { id: 'place-value', title: 'Place Value', ageRange: '6-7' }
            ]
          },
          {
            id: 'addition-subtraction',
            title: 'Addition and Subtraction',
            description: 'Master basic addition and subtraction with numbers up to 20.',
            lessons: [
              { id: 'number-bonds-10', title: 'Number Bonds to 10', ageRange: '5-6' },
              { id: 'addition-to-20', title: 'Adding Numbers to 20', ageRange: '6-7' },
              { id: 'subtraction-20', title: 'Subtracting Numbers to 20', ageRange: '6-7' }
            ]
          }
        ]
      },
      {
        id: 'measurement',
        title: 'Measurement',
        subtopics: [
          {
            id: 'length-height',
            title: 'Length and Height',
            description: 'Compare and measure lengths using standard units.',
            lessons: [
              { id: 'comparing-size', title: 'Comparing Sizes', ageRange: '5-6' },
              { id: 'measuring-cm', title: 'Measuring in Centimeters', ageRange: '6-7' }
            ]
          }
        ]
      }
    ]
  },
  'key-stage-2': {
    id: 'key-stage-2',
    title: 'Key Stage 2',
    ageRange: '7-11',
    description: 'Advanced number operations, fractions, decimals, and geometry.',
    topics: [
      {
        id: 'multiplication-division',
        title: 'Multiplication and Division',
        subtopics: [
          {
            id: 'times-tables',
            title: 'Times Tables',
            description: 'Learn multiplication tables up to 12 × 12.',
            lessons: [
              { id: '2-5-10-times', title: '2, 5 and 10 Times Tables', ageRange: '7-8' },
              { id: '3-4-times', title: '3 and 4 Times Tables', ageRange: '8-9' },
              { id: '6-8-times', title: '6 and 8 Times Tables', ageRange: '9-10' },
              { id: '7-9-11-12-times', title: '7, 9, 11 and 12 Times Tables', ageRange: '10-11' }
            ]
          }
        ]
      }
    ]
  }
};