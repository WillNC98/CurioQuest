export interface Lesson {
  id: string;
  title: string;
  ageRange: string;
  description?: string;
}

export interface Subtopic {
  id: string;
  title: string;
  description: string;
  lessons: Lesson[];
}

export interface Topic {
  id: string;
  title: string;
  subtopics: Subtopic[];
}

export interface KeyStageContent {
  id: string;
  title: string;
  ageRange: string;
  description: string;
  topics: Topic[];
}

export interface UserProgress {
  completedLessons: string[];
  lastAccessed?: string;
  currentLesson?: string;
}