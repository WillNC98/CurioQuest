
// Now create the complete curriculum by combining Key Stage 1 with the base stages
export const mathematicsCurriculum = {
  'key-stage-1': {
    title: 'Key Stage 1 (Ages 5-7)',
    topics: [
      {
    id: 'number-place-value',
    title: 'Number & Place Value',
    subtopics: [
        {
            id: 'counting',
            title: 'Counting and Number Patterns',
            lessons: [
                {
                    id: 'counting-100-lesson1',
                    title: 'Number Sequences and Patterns',
                    ageRange: '5-6',
                    content: 'Count forwards and backwards in steps of 1s, 2s, 5s, and 10s',
                    type: 'lesson'
                },
                {
                    id: 'counting-100-lesson2',
                    title: 'Skip Counting: 2s, 5s, 10s',
                    ageRange: '5-6',
                    type: 'lesson'
                },
                {
                    id: 'counting-100-quiz1',
                    title: 'Missing Numbers Quiz',
                    ageRange: '5-6',
                    type: 'quiz'
                },
                {
                    id: 'counting-100-quiz2',
                    title: 'Pattern Recognition',
                    ageRange: '5-6',
                    type: 'quiz'
                },
                {
                    id: 'counting-100-game1',
                    title: 'Number Line Jumper',
                    ageRange: '5-6',
                    type: 'game'
                },
                {
                    id: 'counting-100-game2',
                    title: 'Counting Hopscotch',
                    ageRange: '5-6',
                    type: 'game'
                }
            ]
        },
        {
            id: 'place-value-tens-ones',
            title: 'Tens and Ones',
            lessons: [
                {
                    id: 'place-value-tens-ones-lesson1',
                    title: 'Understanding Tens and Ones',
                    ageRange: '6-7',
                    content: 'Understand place value in two-digit numbers',
                    type: 'lesson'
                },
                {
                    id: 'place-value-tens-ones-lesson2',
                    title: 'Breaking Down Numbers',
                    ageRange: '6-7',
                    type: 'lesson'
                },
                {
                    id: 'place-value-tens-ones-quiz1',
                    title: 'Place Value Challenge',
                    ageRange: '6-7',
                    type: 'quiz'
                },
                {
                    id: 'place-value-tens-ones-quiz2',
                    title: 'Number Composition',
                    ageRange: '6-7',
                    type: 'quiz'
                },
                {
                    id: 'place-value-tens-ones-game1',
                    title: 'Place Value Builder',
                    ageRange: '6-7',
                    type: 'game'
                },
                {
                    id: 'place-value-tens-ones-game2',
                    title: 'Digit Detective',
                    ageRange: '6-7',
                    type: 'game'
                }
            ]
        }
    ]
},
{
    id: 'addition-subtraction',
    title: 'Addition & Subtraction',
    subtopics: [
        {
            id: 'addition-basics',
            title: 'Understanding Addition',
            activities: [
                {
                    id: 'lesson-what-is-addition',
                    type: 'lesson',
                    title: 'What is Addition? – Using Blocks and Counting Objects',
                    ageRange: '5-6',
                    content: 'Children learn the concept of addition using physical objects and block activities.'
                },
                {
                    id: 'quiz-find-the-sum',
                    type: 'quiz',
                    title: 'Find the Sum Quiz',
                    ageRange: '5-6'
                },
                {
                    id: 'game-addition-adventure-puzzle',
                    type: 'game',
                    title: 'Addition Adventure Puzzle',
                    ageRange: '5-6'
                },
                {
                    id: 'lesson-number-line-addition',
                    type: 'lesson',
                    title: 'Adding on a Number Line – Physical and Digital Practice',
                    ageRange: '5-6',
                    content: 'Children practice adding on number lines with both physical and digital tools.'
                },
                {
                    id: 'quiz-identify-sum',
                    type: 'quiz',
                    title: 'Identify the Sum Quiz',
                    ageRange: '5-6'
                },
                {
                    id: 'game-number-line-race',
                    type: 'game',
                    title: 'Number Line Race',
                    ageRange: '5-6'
                }
            ]
        },
        {
            id: 'subtraction-basics',
            title: 'Understanding Subtraction',
            activities: [
                {
                    id: 'lesson-what-is-subtraction',
                    type: 'lesson',
                    title: 'What is Subtraction? – Real-World Problem Examples',
                    ageRange: '6-7',
                    content: 'Exploring subtraction using real-life problem-solving contexts.'
                },
                {
                    id: 'quiz-identify-difference',
                    type: 'quiz',
                    title: 'Identify the Difference Quiz',
                    ageRange: '6-7'
                },
                {
                    id: 'game-subtraction-smash',
                    type: 'game',
                    title: 'Subtraction Smash',
                    ageRange: '6-7'
                },
                {
                    id: 'lesson-number-line-subtraction',
                    type: 'lesson',
                    title: 'Subtraction on a Number Line',
                    ageRange: '6-7',
                    content: 'Using a number line for subtraction practice with simple problems.'
                },
                {
                    id: 'quiz-number-line-subtraction',
                    type: 'quiz',
                    title: 'Number Line Subtraction Quiz',
                    ageRange: '6-7'
                },
                {
                    id: 'game-subtraction-maze',
                    type: 'game',
                    title: 'Subtraction Maze',
                    ageRange: '6-7'
                }
            ]
        },
        {
            id: 'number-bonds',
            title: 'Number Bonds to 10',
            activities: [
                {
                    id: 'lesson-number-bonds',
                    type: 'lesson',
                    title: 'Number Bonds to 10 – Using Pairs of Blocks',
                    ageRange: '5-6',
                    content: 'Exploring number pairs that make 10 using blocks and matching games.'
                },
                {
                    id: 'quiz-match-the-bonds',
                    type: 'quiz',
                    title: 'Match the Bonds Quiz',
                    ageRange: '5-6'
                },
                {
                    id: 'game-number-bonds-memory',
                    type: 'game',
                    title: 'Number Bonds Memory Match',
                    ageRange: '5-6'
                }
            ]
        },
        {
            id: 'addition-subtraction-challenge',
            title: 'Addition & Subtraction Mastery Challenge',
            activities: [
                {
                    id: 'challenge-number-ninja',
                    type: 'challenge',
                    title: 'Number Ninja Badge Challenge',
                    ageRange: '6-7',
                    content: 'Complete all addition and subtraction activities to unlock the Number Ninja Badge.'
                },
                {
                    id: 'reward-number-ninja-badge',
                    type: 'reward',
                    title: 'Unlock Number Ninja Badge',
                    ageRange: '6-7'
                }
            ]
        }
    ]
},
{
  id: 'multiplication-division',
  title: 'Multiplication & Division',
  subtopics: [
    {
      id: 'multiplication-basics',
      title: 'Understanding Multiplication',
      activities: [
        {
          id: 'lesson-intro-multiplication',
          type: 'lesson',
          title: 'Introduction to Multiplication – Visual Groups of Objects',
          ageRange: '6-7',
          content: 'Children learn the basics of multiplication by grouping and counting objects.'
        },
        {
          id: 'quiz-identify-multiplication-groups',
          type: 'quiz',
          title: 'Identify Multiplication Groups Quiz',
          ageRange: '6-7'
        },
        {
          id: 'game-multiplication-treasure-hunt',
          type: 'game',
          title: 'Multiplication Treasure Hunt',
          ageRange: '6-7'
        },
        {
          id: 'lesson-counting-2s-5s-10s',
          type: 'lesson',
          title: 'Counting in 2s, 5s, and 10s – Using Song-Based Repetition',
          ageRange: '6-7',
          content: 'Children practice counting by 2s, 5s, and 10s using songs and patterns.'
        },
        {
          id: 'quiz-skip-counting',
          type: 'quiz',
          title: 'Skip Counting Quiz',
          ageRange: '6-7'
        },
        {
          id: 'game-counting-pattern-challenge',
          type: 'game',
          title: 'Counting Pattern Challenge',
          ageRange: '6-7'
        }
      ]
    },
    {
      id: 'using-arrays',
      title: 'Using Arrays for Multiplication',
      activities: [
        {
          id: 'lesson-using-arrays',
          type: 'lesson',
          title: 'Using Arrays to Multiply',
          ageRange: '6-7',
          content: 'Children explore arrays as a way to understand multiplication concepts visually.'
        },
        {
          id: 'quiz-identify-arrays',
          type: 'quiz',
          title: 'Identify Arrays Quiz',
          ageRange: '6-7'
        },
        {
          id: 'game-array-match',
          type: 'game',
          title: 'Array Match',
          ageRange: '6-7'
        }
      ]
    },
    {
      id: 'division-basics',
      title: 'Understanding Division',
      activities: [
        {
          id: 'lesson-intro-division',
          type: 'lesson',
          title: 'Introduction to Division as Sharing',
          ageRange: '6-7',
          content: 'Children learn about division through sharing objects equally.'
        },
        {
          id: 'quiz-sharing-and-grouping',
          type: 'quiz',
          title: 'Sharing and Grouping Quiz',
          ageRange: '6-7'
        },
        {
          id: 'game-division-race',
          type: 'game',
          title: 'Division Race',
          ageRange: '6-7'
        }
      ]
    },
    {
      id: 'doubling-halving',
      title: 'Doubling and Halving Basics',
      activities: [
        {
          id: 'lesson-doubling-halving',
          type: 'lesson',
          title: 'Doubling and Halving Basics',
          ageRange: '6-7',
          content: 'Children learn the concepts of doubling and halving with visual aids and hands-on activities.'
        },
        {
          id: 'quiz-double-or-half',
          type: 'quiz',
          title: 'Double or Half Quiz',
          ageRange: '6-7'
        },
        {
          id: 'game-halving-race',
          type: 'game',
          title: 'Halving Race',
          ageRange: '6-7'
        }
      ]
    },
    {
      id: 'multiplication-division-challenge',
      title: 'Multiplication & Division Mastery Challenge',
      activities: [
        {
          id: 'challenge-multiplication-master',
          type: 'challenge',
          title: 'Multiplication Master Badge Challenge',
          ageRange: '6-7',
          content: 'Complete all multiplication and division activities to unlock the Multiplication Master Badge.'
        },
        {
          id: 'reward-multiplication-badge',
          type: 'reward',
          title: 'Unlock Multiplication Master Badge',
          ageRange: '6-7'
        }
      ]
    }
  ]
},
{
  id: 'fractions',
  title: 'Fractions',
  subtopics: [
    {
      id: 'fractions-basics',
      title: 'Understanding Fractions Basics',
      activities: [
        {
          id: 'lesson-what-is-a-half',
          type: 'lesson',
          title: 'What is a Half? – Using Shapes and Dividing Objects',
          ageRange: '6-7',
          content: 'Children explore the concept of a half using shapes and real-world objects.'
        },
        {
          id: 'quiz-identify-halves',
          type: 'quiz',
          title: 'Identify Halves Quiz',
          ageRange: '6-7'
        },
        {
          id: 'game-half-the-shape',
          type: 'game',
          title: 'Half the Shape Game',
          ageRange: '6-7'
        },
        {
          id: 'lesson-what-is-a-quarter',
          type: 'lesson',
          title: 'What is a Quarter? – Dividing Shapes into Four Parts',
          ageRange: '6-7',
          content: 'Children learn how to divide shapes and objects into four equal parts.'
        },
        {
          id: 'quiz-identify-quarters',
          type: 'quiz',
          title: 'Identify Quarters Quiz',
          ageRange: '6-7'
        },
        {
          id: 'game-quarter-matching-game',
          type: 'game',
          title: 'Quarter Matching Game',
          ageRange: '6-7'
        }
      ]
    },
    {
      id: 'fractions-number-line',
      title: 'Fractions on a Number Line',
      activities: [
        {
          id: 'lesson-fractions-number-line',
          type: 'lesson',
          title: 'Fractions on a Number Line',
          ageRange: '6-7',
          content: 'Exploring fractions visually on a number line for conceptual clarity.'
        },
        {
          id: 'quiz-identify-fractions-on-number-line',
          type: 'quiz',
          title: 'Identify Fractions on the Number Line Quiz',
          ageRange: '6-7'
        },
        {
          id: 'game-fraction-line-explorer',
          type: 'game',
          title: 'Fraction Line Explorer',
          ageRange: '6-7'
        }
      ]
    },
    {
      id: 'fractions-interactive',
      title: 'Fractions Interactive Learning and Games',
      activities: [
        {
          id: 'lesson-fraction-pizza',
          type: 'lesson',
          title: 'Fraction Pizza Maker',
          ageRange: '6-7',
          content: 'Children divide pizzas into halves and quarters as a fun learning activity.'
        },
        {
          id: 'quiz-identify-pizza-fractions',
          type: 'quiz',
          title: 'Identify the Pizza Fraction Quiz',
          ageRange: '6-7'
        },
        {
          id: 'game-fraction-pizza-maker',
          type: 'game',
          title: 'Fraction Pizza Maker Game',
          ageRange: '6-7'
        },
        {
          id: 'lesson-halves-quarters-numbers',
          type: 'lesson',
          title: 'Halves and Quarters of Numbers',
          ageRange: '6-7',
          content: 'Children will work with numerical fractions using real-world objects.'
        },
        {
          id: 'quiz-fraction-number-quiz',
          type: 'quiz',
          title: 'Fraction Number Quiz',
          ageRange: '6-7'
        },
        {
          id: 'game-fraction-colour-match',
          type: 'game',
          title: 'Fraction Colour Match Game',
          ageRange: '6-7'
        }
      ]
    },
    {
      id: 'fractions-challenge',
      title: 'Fractions Mastery Challenge',
      activities: [
        {
          id: 'challenge-fraction-hero',
          type: 'challenge',
          title: 'Fraction Hero Badge Challenge',
          ageRange: '6-7',
          content: 'Complete all fraction-related lessons, quizzes, and games to unlock the Fraction Hero Badge.'
        },
        {
          id: 'reward-fraction-hero-badge',
          type: 'reward',
          title: 'Unlock Fraction Hero Badge',
          ageRange: '6-7'
        }
      ]
    }
  ]
},
{
  id: 'measurement',
  title: 'Measurement',
  subtopics: [
    {
      id: 'measuring-lengths',
      title: 'Measuring Lengths and Heights',
      activities: [
        {
          id: 'lesson-measuring-lengths-intro',
          type: 'lesson',
          title: 'Introduction to Measuring Lengths',
          ageRange: '5-7',
          content: 'Learn how to measure lengths using rulers and cubes.'
        },
        {
          id: 'quiz-identify-longer-shorter',
          type: 'quiz',
          title: 'Identify Longer and Shorter',
          ageRange: '5-7'
        },
        {
          id: 'game-length-comparison-game',
          type: 'game',
          title: 'Length Comparison Game',
          ageRange: '5-7'
        },
        {
          id: 'lesson-non-standard-units',
          type: 'lesson',
          title: 'Measuring with Non-Standard Units',
          ageRange: '5-7',
          content: 'Measure objects using blocks, hands, and everyday items.'
        },
        {
          id: 'quiz-identify-measurement-units',
          type: 'quiz',
          title: 'Identify Measurement Units Quiz',
          ageRange: '5-7'
        },
        {
          id: 'game-measurement-adventure-hunt',
          type: 'game',
          title: 'Measurement Adventure Hunt',
          ageRange: '5-7'
        }
      ]
    },
    {
      id: 'weight-capacity',
      title: 'Weight and Capacity',
      activities: [
        {
          id: 'lesson-comparing-weights',
          type: 'lesson',
          title: 'Comparing Weights and Capacity',
          ageRange: '5-7',
          content: 'Use water play and objects to compare weights and capacity.'
        },
        {
          id: 'quiz-identify-heavier-object',
          type: 'quiz',
          title: 'Identify the Heavier Object Quiz',
          ageRange: '5-7'
        },
        {
          id: 'game-water-measurement-treasure-hunt',
          type: 'game',
          title: 'Water Measurement Treasure Hunt',
          ageRange: '5-7'
        }
      ]
    },
    {
      id: 'time',
      title: 'Understanding Time',
      activities: [
        {
          id: 'lesson-telling-time',
          type: 'lesson',
          title: 'Telling Time – Hour and Half Hour',
          ageRange: '5-7',
          content: 'Learn to tell time using the hour and half-hour on a clock.'
        },
        {
          id: 'quiz-match-the-clock',
          type: 'quiz',
          title: 'Match the Clock to the Time Quiz',
          ageRange: '5-7'
        },
        {
          id: 'game-time-explorer',
          type: 'game',
          title: 'Time Explorer Game',
          ageRange: '5-7'
        },
        {
          id: 'lesson-chronological-order',
          type: 'lesson',
          title: 'Ordering Events Chronologically',
          ageRange: '5-7',
          content: 'Practice sequencing daily events using timeline activities.'
        },
        {
          id: 'quiz-chronology-quiz',
          type: 'quiz',
          title: 'Chronology Quiz',
          ageRange: '5-7'
        },
        {
          id: 'game-time-sorting-challenge',
          type: 'game',
          title: 'Time Sorting Challenge',
          ageRange: '5-7'
        }
      ]
    },
    {
      id: 'measurement-challenge',
      title: 'Measurement Mastery Challenge',
      activities: [
        {
          id: 'challenge-measurement-master',
          type: 'challenge',
          title: 'Measurement Mastery Badge Challenge',
          ageRange: '5-7',
          content: 'Complete all measurement lessons, quizzes, and games to unlock the badge.'
        },
        {
          id: 'reward-measurement-badge',
          type: 'reward',
          title: 'Unlock Measurement Master Badge',
          ageRange: '5-7'
        }
      ]
    }
  ]
},
{
  id: 'geometry-shapes',
  title: 'Geometry Shapes',
  subtopics: [
    {
      id: '2d-shapes',
      title: '2D Shapes',
      activities: [
        {
          id: 'lesson-identifying-2d-shapes',
          type: 'lesson',
          title: 'Identifying 2D Shapes',
          ageRange: '5-7',
          content: 'Learn to identify and name basic 2D shapes such as circles, squares, and triangles.'
        },
        {
          id: 'quiz-match-2d-shape',
          type: 'quiz',
          title: 'Match the 2D Shape with Name Quiz',
          ageRange: '5-7'
        },
        {
          id: 'game-shape-sorting',
          type: 'game',
          title: 'Shape Sorting Game',
          ageRange: '5-7'
        },
        {
          id: 'lesson-sides-corners',
          type: 'lesson',
          title: 'Counting Sides and Corners',
          ageRange: '5-7',
          content: 'Learn to count sides and corners of 2D shapes.'
        },
        {
          id: 'quiz-shape-properties',
          type: 'quiz',
          title: 'Shape Properties Quiz',
          ageRange: '5-7'
        },
        {
          id: 'game-shape-detective',
          type: 'game',
          title: 'Shape Detective Game',
          ageRange: '5-7'
        }
      ]
    },
    {
      id: '3d-shapes',
      title: '3D Shapes',
      activities: [
        {
          id: 'lesson-identifying-3d-shapes',
          type: 'lesson',
          title: 'Identifying 3D Shapes',
          ageRange: '5-7',
          content: 'Identify and name basic 3D shapes such as spheres, cubes, and cones.'
        },
        {
          id: 'quiz-match-3d-shape',
          type: 'quiz',
          title: 'Match the 3D Shape with Name Quiz',
          ageRange: '5-7'
        },
        {
          id: 'game-3d-shape-sorting',
          type: 'game',
          title: '3D Shape Sorting Game',
          ageRange: '5-7'
        },
        {
          id: 'lesson-vertices-edges-faces',
          type: 'lesson',
          title: 'Vertices, Edges, and Faces',
          ageRange: '6-7',
          content: 'Learn to identify vertices, edges, and faces in 3D shapes.'
        },
        {
          id: 'quiz-vertices-edges-faces',
          type: 'quiz',
          title: 'Identify Shape Properties Quiz',
          ageRange: '6-7'
        },
        {
          id: 'game-3d-shape-builder',
          type: 'game',
          title: '3D Shape Builder Game',
          ageRange: '6-7'
        }
      ]
    },
    {
      id: 'geometry-shapes-challenge',
      title: 'Shape Mastery Challenge',
      activities: [
        {
          id: 'challenge-shape-explorer',
          type: 'challenge',
          title: 'Shape Explorer Badge Challenge',
          ageRange: '5-7',
          content: 'Complete all shape lessons, quizzes, and games to unlock the Shape Explorer Badge.'
        },
        {
          id: 'reward-shape-explorer-badge',
          type: 'reward',
          title: 'Unlock Shape Explorer Badge',
          ageRange: '5-7'
        }
      ]
    }
  ]
},
      {
        id: 'geometry-position-direction',
        title: 'Geometry – Position & Direction',
        subtopics: [
          {
            id: 'position-basics',
            title: 'Understanding Position and Movement',
            activities: [
              {
                id: 'lesson-position-basics',
                type: 'lesson',
                title: 'Understanding Left, Right, Top, Bottom',
                ageRange: '5-7',
                content: 'Learn the basics of positional language using everyday objects.'
              },
              {
                id: 'quiz-position-basics',
                type: 'quiz',
                title: 'Identify the Position Quiz',
                ageRange: '5-7'
              },
              {
                id: 'game-direction-detective',
                type: 'game',
                title: 'Direction Detective Maze Game',
                ageRange: '5-7'
              }
            ]
          },
          {
            id: 'turns-rotations',
            title: 'Turns and Rotations',
            activities: [
              {
                id: 'lesson-turns-rotations',
                type: 'lesson',
                title: 'Turns and Rotations – Whole, Half, Quarter Turns',
                ageRange: '5-7',
                content: 'Understand whole, half, and quarter turns using physical movements and diagrams.'
              },
              {
                id: 'quiz-turns-rotations',
                type: 'quiz',
                title: 'Identify the Turn Direction Quiz',
                ageRange: '5-7'
              },
              {
                id: 'game-turn-matching',
                type: 'game',
                title: 'Turn Matching Game',
                ageRange: '5-7'
              }
            ]
          },
          {
            id: 'positional-language',
            title: 'Positional Language with Objects',
            activities: [
              {
                id: 'lesson-using-positional-language',
                type: 'lesson',
                title: 'Using Positional Language with Objects',
                ageRange: '5-7',
                content: 'Use positional language with physical and digital objects.'
              },
              {
                id: 'quiz-positional-language',
                type: 'quiz',
                title: 'Identify Object Positions Quiz',
                ageRange: '5-7'
              },
              {
                id: 'game-treasure-map-hunt',
                type: 'game',
                title: 'Treasure Map Hunt Game',
                ageRange: '5-7'
              }
            ]
          },
          {
            id: 'geometry-position-challenge',
            title: 'Position & Direction Mastery Challenge',
            activities: [
              {
                id: 'challenge-position-master',
                type: 'challenge',
                title: 'Position Mastery Badge Challenge',
                ageRange: '5-7',
                content: 'Complete all lessons, quizzes, and games to unlock the Position Master Badge.'
              },
              {
                id: 'reward-position-master-badge',
                type: 'reward',
                title: 'Unlock Position Master Badge',
                ageRange: '5-7'
              }
            ]
          }
        ]
      }
    ]
  },
  'key-stage-2': {
    title: 'Key Stage 2 (Ages 7-11)',
    topics: [
      {
        id: 'number-place-value',
        title: 'Number & Place Value',
        subtopics: [
          {
            id: 'understanding-place-value',
            title: 'Understanding Place Value',
            activities: [
              {
                id: 'lesson-intro-place-value',
                type: 'lesson',
                title: 'Introduction to Place Value',
                ageRange: '7-8',
                content: 'Understand the place value of digits up to 1,000,000 using base-10 blocks and grids.'
              },
              {
                id: 'quiz-place-value-identification',
                type: 'quiz',
                title: 'Place Value Identification Quiz',
                ageRange: '7-8'
              },
              {
                id: 'game-place-value-tower',
                type: 'game',
                title: 'Place Value Tower',
                ageRange: '7-8'
              }
            ]
          },
          {
            id: 'ordering-and-comparing-numbers',
            title: 'Ordering and Comparing Numbers',
            activities: [
              {
                id: 'lesson-ordering-numbers',
                type: 'lesson',
                title: 'Ordering and Comparing Numbers',
                ageRange: '7-8',
                content: 'Learn how to compare and order numbers using number lines and grids.'
              },
              {
                id: 'quiz-comparing-numbers',
                type: 'quiz',
                title: 'Comparing Numbers Quiz',
                ageRange: '7-8'
              },
              {
                id: 'game-number-line-challenge',
                type: 'game',
                title: 'Number Line Challenge',
                ageRange: '7-8'
              }
            ]
          },
          {
            id: 'rounding-numbers',
            title: 'Rounding Numbers',
            activities: [
              {
                id: 'lesson-rounding-basics',
                type: 'lesson',
                title: 'Rounding Basics',
                ageRange: '8-9',
                content: 'Introduction to rounding numbers to the nearest 10, 100, and 1000 using visual aids.'
              },
              {
                id: 'quiz-rounding-quiz',
                type: 'quiz',
                title: 'Rounding Quiz',
                ageRange: '8-9'
              },
              {
                id: 'game-rounding-race',
                type: 'game',
                title: 'Rounding Race Game',
                ageRange: '8-9'
              }
            ]
          },
          {
            id: 'roman-numerals',
            title: 'Roman Numerals',
            activities: [
              {
                id: 'lesson-roman-numerals-intro',
                type: 'lesson',
                title: 'Introduction to Roman Numerals',
                ageRange: '9-10',
                content: 'Explore Roman numerals and learn to represent numbers up to 100.'
              },
              {
                id: 'quiz-roman-numerals-quiz',
                type: 'quiz',
                title: 'Roman Numerals Quiz',
                ageRange: '9-10'
              },
              {
                id: 'game-roman-numerals-puzzle',
                type: 'game',
                title: 'Roman Numerals Puzzle Game',
                ageRange: '9-10'
              }
            ]
          },
          {
            id: 'number-place-value-challenge',
            title: 'Number & Place Value Mastery Challenge',
            activities: [
              {
                id: 'challenge-place-value-master',
                type: 'challenge',
                title: 'Place Value Mastery Badge',
                ageRange: '7-10',
                content: 'Complete all number and place value activities to unlock the Place Value Mastery Badge.'
              },
              {
                id: 'reward-place-value-badge',
                type: 'reward',
                title: 'Unlock Place Value Mastery Badge',
                ageRange: '7-10'
              }
            ]
          }
        ]
      },
      {
    id: 'addition-subtraction',
    title: 'Addition & Subtraction',

        subtopics: [
          {
            id: 'basic-addition',
            title: 'Basic Addition Concepts',
            activities: [
              {
                id: 'lesson-what-is-addition',
                type: 'lesson',
                title: 'What is Addition?',
                ageRange: '7-8',
                content: 'Learn the basics of addition using visual aids and number lines.'
              },
              {
                id: 'quiz-addition-quiz',
                type: 'quiz',
                title: 'Addition Quiz',
                ageRange: '7-8'
              },
              {
                id: 'game-addition-adventure',
                type: 'game',
                title: 'Addition Adventure',
                ageRange: '7-8'
              }
            ]
          },
          {
            id: 'basic-subtraction',
            title: 'Basic Subtraction Concepts',
            activities: [
              {
                id: 'lesson-what-is-subtraction',
                type: 'lesson',
                title: 'What is Subtraction?',
                ageRange: '7-8',
                content: 'Learn the basics of subtraction using visual aids and number lines.'
              },
              {
                id: 'quiz-subtraction-quiz',
                type: 'quiz',
                title: 'Subtraction Quiz',
                ageRange: '7-8'
              },
              {
                id: 'game-subtraction-challenge',
                type: 'game',
                title: 'Subtraction Smash',
                ageRange: '7-8'
              }
            ]
          },
          {
            id: 'addition-with-carrying',
            title: 'Addition with Carrying',
            activities: [
              {
                id: 'lesson-addition-carrying',
                type: 'lesson',
                title: 'Addition with Carrying',
                ageRange: '8-9',
                content: 'Understand how to perform addition with carrying using place value blocks.'
              },
              {
                id: 'quiz-addition-carrying-quiz',
                type: 'quiz',
                title: 'Addition with Carrying Quiz',
                ageRange: '8-9'
              },
              {
                id: 'game-carrying-challenge',
                type: 'game',
                title: 'Carrying Addition Race',
                ageRange: '8-9'
              }
            ]
          },
          {
            id: 'subtraction-with-regrouping',
            title: 'Subtraction with Regrouping',
            activities: [
              {
                id: 'lesson-subtraction-regrouping',
                type: 'lesson',
                title: 'Subtraction with Regrouping',
                ageRange: '8-9',
                content: 'Learn subtraction with regrouping using visual aids and practice problems.'
              },
              {
                id: 'quiz-subtraction-regrouping-quiz',
                type: 'quiz',
                title: 'Subtraction with Regrouping Quiz',
                ageRange: '8-9'
              },
              {
                id: 'game-regrouping-challenge',
                type: 'game',
                title: 'Regrouping Puzzle Game',
                ageRange: '8-9'
              }
            ]
          },
          {
            id: 'mental-arithmetic',
            title: 'Mental Arithmetic Strategies',
            activities: [
              {
                id: 'lesson-mental-arithmetic',
                type: 'lesson',
                title: 'Mental Maths Tricks for Addition & Subtraction',
                ageRange: '9-10',
                content: 'Practice mental strategies for solving addition and subtraction problems faster.'
              },
              {
                id: 'quiz-mental-arithmetic-quiz',
                type: 'quiz',
                title: 'Mental Arithmetic Quiz',
                ageRange: '9-10'
              },
              {
                id: 'game-mental-maths-challenge',
                type: 'game',
                title: 'Mental Maths Speed Game',
                ageRange: '9-10'
              }
            ]
          },
          {
            id: 'addition-subtraction-challenge',
            title: 'Addition & Subtraction Mastery Challenge',
            activities: [
              {
                id: 'challenge-addition-subtraction-master',
                type: 'challenge',
                title: 'Addition & Subtraction Mastery Badge',
                ageRange: '7-10',
                content: 'Complete all activities under Addition & Subtraction to unlock the mastery badge.'
              },
              {
                id: 'reward-addition-subtraction-badge',
                type: 'reward',
                title: 'Unlock Addition & Subtraction Badge',
                ageRange: '7-10'
              }
            ]
          }
        ]
      },
      {
    id: 'multiplication-division',
    title: 'Multiplication & Division',
    subtopics: [
        {
            id: 'basic-multiplication',
            title: 'Basic Multiplication Concepts',
            activities: [
                {
                    id: 'lesson-intro-multiplication',
                    type: 'lesson',
                    title: 'Introduction to Multiplication – Grouping Objects',
                    ageRange: '7-8',
                    content: 'Understand the concept of multiplication using groups of objects.'
                },
                {
                    id: 'quiz-multiplication-quiz',
                    type: 'quiz',
                    title: 'Multiplication Quiz',
                    ageRange: '7-8'
                },
                {
                    id: 'game-multiplication-treasure-hunt',
                    type: 'game',
                    title: 'Multiplication Treasure Hunt',
                    ageRange: '7-8'
                }
            ]
        },
        {
            id: 'times-tables',
            title: 'Times Tables Mastery',
            activities: [
                {
                    id: 'lesson-times-tables',
                    type: 'lesson',
                    title: 'Learning Times Tables for 2, 5, and 10',
                    ageRange: '7-9',
                    content: 'Practice the times tables through songs, patterns, and visual aids.'
                },
                {
                    id: 'quiz-times-tables-quiz',
                    type: 'quiz',
                    title: 'Times Tables Quiz',
                    ageRange: '7-9'
                },
                {
                    id: 'game-times-tables-hop',
                    type: 'game',
                    title: 'Times Tables Hopscotch Game',
                    ageRange: '7-9'
                }
            ]
        },
        {
            id: 'basic-division',
            title: 'Basic Division Concepts',
            activities: [
                {
                    id: 'lesson-division-intro',
                    type: 'lesson',
                    title: 'What is Division? – Sharing & Grouping',
                    ageRange: '8-9',
                    content: 'Learn the concept of division through sharing and grouping objects.'
                },
                {
                    id: 'quiz-division-quiz',
                    type: 'quiz',
                    title: 'Division Quiz',
                    ageRange: '8-9'
                },
                {
                    id: 'game-division-race',
                    type: 'game',
                    title: 'Division Race Game',
                    ageRange: '8-9'
                }
            ]
        },
        {
            id: 'multiplying-2-digit-numbers',
            title: 'Multiplying 2-Digit Numbers',
            activities: [
                {
                    id: 'lesson-multiplying-2-digits',
                    type: 'lesson',
                    title: 'Multiplying 2-Digit Numbers Using Area Model',
                    ageRange: '8-10',
                    content: 'Learn to multiply 2-digit numbers using the area model method.'
                },
                {
                    id: 'quiz-multiplying-2-digit-quiz',
                    type: 'quiz',
                    title: '2-Digit Multiplication Quiz',
                    ageRange: '8-10'
                },
                {
                    id: 'game-2-digit-multiplication-game',
                    type: 'game',
                    title: '2-Digit Multiplication Puzzle',
                    ageRange: '8-10'
                }
            ]
        },
        {
            id: 'division-with-remainders',
            title: 'Division with Remainders',
            activities: [
                {
                    id: 'lesson-division-remainders',
                    type: 'lesson',
                    title: 'Division with Remainders',
                    ageRange: '8-10',
                    content: 'Practice division with remainders using visual aids and practice questions.'
                },
                {
                    id: 'quiz-division-remainders-quiz',
                    type: 'quiz',
                    title: 'Division with Remainders Quiz',
                    ageRange: '8-10'
                },
                {
                    id: 'game-division-remainders-game',
                    type: 'game',
                    title: 'Division Remainders Race',
                    ageRange: '8-10'
                }
            ]
        },
        {
            id: 'multiplication-division-challenge',
            title: 'Multiplication & Division Mastery Challenge',
            activities: [
                {
                    id: 'challenge-multiplication-division-master',
                    type: 'challenge',
                    title: 'Multiplication & Division Mastery Badge',
                    ageRange: '7-10',
                    content: 'Complete all activities under Multiplication & Division to unlock the badge.'
                },
                {
                    id: 'reward-multiplication-division-badge',
                    type: 'reward',
                    title: 'Unlock Multiplication & Division Mastery Badge',
                    ageRange: '7-10'
                }
            ]
        }
    ]
},
{
    id: 'fractions',
    title: 'Fractions',
    subtopics: [
        {
            id: 'fractions-basics',
            title: 'Understanding Fractions Basics',
            activities: [
                {
                    id: 'lesson-what-is-a-fraction',
                    type: 'lesson',
                    title: 'What is a Fraction? – Visualizing Fractions',
                    ageRange: '7-8',
                    content: 'Understand fractions using shapes and real-life objects.'
                },
                {
                    id: 'quiz-identify-fractions',
                    type: 'quiz',
                    title: 'Identify Fractions Quiz',
                    ageRange: '7-8'
                },
                {
                    id: 'game-fraction-pizza',
                    type: 'game',
                    title: 'Fraction Pizza Maker',
                    ageRange: '7-8'
                }
            ]
        },
        {
            id: 'fractions-halves-quarters',
            title: 'Halves and Quarters',
            activities: [
                {
                    id: 'lesson-halves-quarters',
                    type: 'lesson',
                    title: 'Halves and Quarters with Shapes',
                    ageRange: '7-8',
                    content: 'Learn how to divide shapes into halves and quarters using visual aids.'
                },
                {
                    id: 'quiz-halves-quarters-quiz',
                    type: 'quiz',
                    title: 'Halves and Quarters Quiz',
                    ageRange: '7-8'
                },
                {
                    id: 'game-halves-quarters-game',
                    type: 'game',
                    title: 'Halves and Quarters Match Game',
                    ageRange: '7-8'
                }
            ]
        },
        {
            id: 'fractions-on-number-line',
            title: 'Fractions on a Number Line',
            activities: [
                {
                    id: 'lesson-fractions-number-line',
                    type: 'lesson',
                    title: 'Placing Fractions on a Number Line',
                    ageRange: '8-9',
                    content: 'Understand how to place fractions accurately on a number line.'
                },
                {
                    id: 'quiz-fractions-number-line',
                    type: 'quiz',
                    title: 'Number Line Fractions Quiz',
                    ageRange: '8-9'
                },
                {
                    id: 'game-fraction-line-game',
                    type: 'game',
                    title: 'Fraction Line Explorer',
                    ageRange: '8-9'
                }
            ]
        },
        {
            id: 'equivalent-fractions',
            title: 'Equivalent Fractions',
            activities: [
                {
                    id: 'lesson-equivalent-fractions',
                    type: 'lesson',
                    title: 'Introduction to Equivalent Fractions',
                    ageRange: '8-9',
                    content: 'Learn how to identify and create equivalent fractions using visuals.'
                },
                {
                    id: 'quiz-equivalent-fractions-quiz',
                    type: 'quiz',
                    title: 'Equivalent Fractions Quiz',
                    ageRange: '8-9'
                },
                {
                    id: 'game-equivalent-fractions-match',
                    type: 'game',
                    title: 'Equivalent Fractions Match Game',
                    ageRange: '8-9'
                }
            ]
        },
        {
            id: 'adding-fractions',
            title: 'Adding Fractions',
            activities: [
                {
                    id: 'lesson-adding-fractions',
                    type: 'lesson',
                    title: 'Adding Fractions with Like Denominators',
                    ageRange: '8-10',
                    content: 'Learn how to add fractions with like denominators using visual models.'
                },
                {
                    id: 'quiz-adding-fractions-quiz',
                    type: 'quiz',
                    title: 'Adding Fractions Quiz',
                    ageRange: '8-10'
                },
                {
                    id: 'game-adding-fractions-race',
                    type: 'game',
                    title: 'Adding Fractions Race',
                    ageRange: '8-10'
                }
            ]
        },
        {
            id: 'comparing-fractions',
            title: 'Comparing Fractions',
            activities: [
                {
                    id: 'lesson-comparing-fractions',
                    type: 'lesson',
                    title: 'Comparing Fractions Using Visual Models',
                    ageRange: '9-10',
                    content: 'Learn to compare fractions with different denominators.'
                },
                {
                    id: 'quiz-comparing-fractions-quiz',
                    type: 'quiz',
                    title: 'Comparing Fractions Quiz',
                    ageRange: '9-10'
                },
                {
                    id: 'game-fractions-comparison-game',
                    type: 'game',
                    title: 'Fractions Comparison Puzzle',
                    ageRange: '9-10'
                }
            ]
        },
        {
            id: 'fractions-challenge',
            title: 'Fractions Mastery Challenge',
            activities: [
                {
                    id: 'challenge-fractions-master',
                    type: 'challenge',
                    title: 'Fractions Mastery Badge Challenge',
                    ageRange: '7-10',
                    content: 'Complete all fractions lessons, quizzes, and games to unlock the badge.'
                },
                {
                    id: 'reward-fractions-badge',
                    type: 'reward',
                    title: 'Unlock Fractions Mastery Badge',
                    ageRange: '7-10'
                }
            ]
        }
    ]
},
{
    id: 'measurement',
    title: 'Measurement',
    subtopics: [
        {
            id: 'length-mass-capacity',
            title: 'Length, Mass, and Capacity',
            activities: [
                {
                    id: 'lesson-measuring-lengths',
                    type: 'lesson',
                    title: 'Measuring Lengths and Heights',
                    ageRange: '7-9',
                    content: 'Learn to measure lengths using rulers, scales, and measuring tapes.'
                },
                {
                    id: 'quiz-identify-units',
                    type: 'quiz',
                    title: 'Identify Units of Measurement',
                    ageRange: '7-9'
                },
                {
                    id: 'game-measurement-explorer',
                    type: 'game',
                    title: 'Measurement Explorer Challenge',
                    ageRange: '7-9'
                },
                {
                    id: 'lesson-comparing-mass',
                    type: 'lesson',
                    title: 'Comparing Mass and Capacity',
                    ageRange: '7-9',
                    content: 'Compare and order objects based on their mass and capacity.'
                },
                {
                    id: 'quiz-comparing-weights',
                    type: 'quiz',
                    title: 'Comparing Weights and Volumes',
                    ageRange: '7-9'
                },
                {
                    id: 'game-mass-match',
                    type: 'game',
                    title: 'Mass Match Game',
                    ageRange: '7-9'
                }
            ]
        },
        {
            id: 'time',
            title: 'Time',
            activities: [
                {
                    id: 'lesson-telling-time',
                    type: 'lesson',
                    title: 'Telling Time to the Minute',
                    ageRange: '7-9',
                    content: 'Practice reading clocks to the nearest minute and understanding AM/PM.'
                },
                {
                    id: 'quiz-telling-time',
                    type: 'quiz',
                    title: 'Time Reading Quiz',
                    ageRange: '7-9'
                },
                {
                    id: 'game-time-explorer',
                    type: 'game',
                    title: 'Time Explorer Game',
                    ageRange: '7-9'
                },
                {
                    id: 'lesson-time-conversions',
                    type: 'lesson',
                    title: 'Converting Units of Time',
                    ageRange: '8-10',
                    content: 'Convert between seconds, minutes, and hours using practical problems.'
                },
                {
                    id: 'quiz-time-conversions',
                    type: 'quiz',
                    title: 'Time Conversion Quiz',
                    ageRange: '8-10'
                },
                {
                    id: 'game-time-challenge',
                    type: 'game',
                    title: 'Beat the Clock Time Game',
                    ageRange: '8-10'
                }
            ]
        },
        {
            id: 'area-perimeter',
            title: 'Area and Perimeter',
            activities: [
                {
                    id: 'lesson-introduction-area',
                    type: 'lesson',
                    title: 'Introduction to Area',
                    ageRange: '8-10',
                    content: 'Learn how to calculate area using grids and unit squares.'
                },
                {
                    id: 'quiz-area-quiz',
                    type: 'quiz',
                    title: 'Calculate the Area Quiz',
                    ageRange: '8-10'
                },
                {
                    id: 'game-area-builder',
                    type: 'game',
                    title: 'Area Builder Game',
                    ageRange: '8-10'
                },
                {
                    id: 'lesson-introduction-perimeter',
                    type: 'lesson',
                    title: 'Introduction to Perimeter',
                    ageRange: '8-10',
                    content: 'Learn how to calculate perimeter using shapes and measuring tools.'
                },
                {
                    id: 'quiz-perimeter-quiz',
                    type: 'quiz',
                    title: 'Calculate the Perimeter Quiz',
                    ageRange: '8-10'
                },
                {
                    id: 'game-perimeter-challenge',
                    type: 'game',
                    title: 'Perimeter Puzzle Race',
                    ageRange: '8-10'
                }
            ]
        },
        {
            id: 'measurement-challenge',
            title: 'Measurement Mastery Challenge',
            activities: [
                {
                    id: 'challenge-measurement-mastery',
                    type: 'challenge',
                    title: 'Measurement Mastery Badge',
                    ageRange: '9-11',
                    content: 'Complete all measurement lessons, quizzes, and games to earn the badge.'
                },
                {
                    id: 'reward-measurement-master-badge',
                    type: 'reward',
                    title: 'Unlock Measurement Mastery Badge',
                    ageRange: '9-11'
                }
            ]
        }
    ]
},
{
    id: 'geometry-shapes',
    title: 'Geometry – Shapes',
    subtopics: [
        {
            id: '2d-shapes',
            title: '2D Shapes',
            activities: [
                {
                    id: 'lesson-identifying-2d-shapes',
                    type: 'lesson',
                    title: 'Identifying 2D Shapes',
                    ageRange: '7-9',
                    content: 'Identify and name 2D shapes such as circles, squares, triangles, and rectangles.'
                },
                {
                    id: 'quiz-identify-2d-shapes',
                    type: 'quiz',
                    title: 'Identify 2D Shapes Quiz',
                    ageRange: '7-9'
                },
                {
                    id: 'game-2d-shape-sorter',
                    type: 'game',
                    title: '2D Shape Sorting Game',
                    ageRange: '7-9'
                },
                {
                    id: 'lesson-sides-vertices',
                    type: 'lesson',
                    title: 'Counting Sides and Vertices',
                    ageRange: '7-9',
                    content: 'Explore the properties of 2D shapes by counting sides and vertices.'
                },
                {
                    id: 'quiz-sides-vertices',
                    type: 'quiz',
                    title: 'Count Sides and Vertices Quiz',
                    ageRange: '7-9'
                },
                {
                    id: 'game-2d-shape-detective',
                    type: 'game',
                    title: '2D Shape Detective Game',
                    ageRange: '7-9'
                }
            ]
        },
        {
            id: '3d-shapes',
            title: '3D Shapes',
            activities: [
                {
                    id: 'lesson-identifying-3d-shapes',
                    type: 'lesson',
                    title: 'Identifying 3D Shapes',
                    ageRange: '8-10',
                    content: 'Identify and name 3D shapes such as spheres, cubes, cones, and cylinders.'
                },
                {
                    id: 'quiz-identify-3d-shapes',
                    type: 'quiz',
                    title: 'Identify 3D Shapes Quiz',
                    ageRange: '8-10'
                },
                {
                    id: 'game-3d-shape-sorter',
                    type: 'game',
                    title: '3D Shape Sorting Game',
                    ageRange: '8-10'
                },
                {
                    id: 'lesson-edges-vertices-faces',
                    type: 'lesson',
                    title: 'Understanding Edges, Vertices, and Faces',
                    ageRange: '8-10',
                    content: 'Explore the properties of 3D shapes by identifying edges, vertices, and faces.'
                },
                {
                    id: 'quiz-edges-vertices-faces',
                    type: 'quiz',
                    title: 'Edges, Vertices, and Faces Quiz',
                    ageRange: '8-10'
                },
                {
                    id: 'game-3d-shape-builder',
                    type: 'game',
                    title: '3D Shape Builder Game',
                    ageRange: '8-10'
                }
            ]
        },
        {
            id: 'symmetry',
            title: 'Symmetry',
            activities: [
                {
                    id: 'lesson-introduction-symmetry',
                    type: 'lesson',
                    title: 'Introduction to Symmetry',
                    ageRange: '8-10',
                    content: 'Learn about symmetry and how to identify lines of symmetry in shapes.'
                },
                {
                    id: 'quiz-symmetry-quiz',
                    type: 'quiz',
                    title: 'Identify Lines of Symmetry Quiz',
                    ageRange: '8-10'
                },
                {
                    id: 'game-symmetry-mirror-match',
                    type: 'game',
                    title: 'Symmetry Mirror Match Game',
                    ageRange: '8-10'
                },
                {
                    id: 'lesson-symmetry-reflection',
                    type: 'lesson',
                    title: 'Symmetry and Reflection',
                    ageRange: '8-10',
                    content: 'Understand reflection and how it relates to symmetry in shapes.'
                },
                {
                    id: 'quiz-symmetry-reflection',
                    type: 'quiz',
                    title: 'Symmetry and Reflection Quiz',
                    ageRange: '8-10'
                },
                {
                    id: 'game-reflection-puzzle',
                    type: 'game',
                    title: 'Reflection Puzzle Challenge',
                    ageRange: '8-10'
                }
            ]
        },
        {
            id: 'geometry-shapes-challenge',
            title: 'Shapes Mastery Challenge',
            activities: [
                {
                    id: 'challenge-shapes-mastery',
                    type: 'challenge',
                    title: 'Shapes Mastery Badge',
                    ageRange: '9-11',
                    content: 'Complete all shape lessons, quizzes, and games to unlock the Shapes Mastery Badge.'
                },
                {
                    id: 'reward-shapes-master-badge',
                    type: 'reward',
                    title: 'Unlock Shapes Mastery Badge',
                    ageRange: '9-11'
                }
            ]
        }
    ]
},
{
    id: 'geometry-position-direction',
    title: 'Geometry – Position & Direction',
    subtopics: [
        {
            id: 'position-basics',
            title: 'Understanding Position and Movement',
            activities: [
                {
                    id: 'lesson-position-language',
                    type: 'lesson',
                    title: 'Understanding Positional Language',
                    ageRange: '7-9',
                    content: 'Learn basic positional language such as left, right, top, bottom, and middle using interactive objects.'
                },
                {
                    id: 'quiz-position-identification',
                    type: 'quiz',
                    title: 'Identify Positional Language Quiz',
                    ageRange: '7-9'
                },
                {
                    id: 'game-position-treasure-hunt',
                    type: 'game',
                    title: 'Treasure Hunt Game – Positional Clues',
                    ageRange: '7-9'
                },
                {
                    id: 'lesson-using-grids',
                    type: 'lesson',
                    title: 'Using Grids for Position',
                    ageRange: '7-9',
                    content: 'Introduce grids and coordinates to describe position on a 2D plane.'
                },
                {
                    id: 'quiz-grid-coordinates',
                    type: 'quiz',
                    title: 'Identify Grid Positions Quiz',
                    ageRange: '7-9'
                },
                {
                    id: 'game-coordinate-maze',
                    type: 'game',
                    title: 'Coordinate Maze Game',
                    ageRange: '7-9'
                }
            ]
        },
        {
            id: 'direction-turns-rotations',
            title: 'Turns and Rotations',
            activities: [
                {
                    id: 'lesson-turns-rotations',
                    type: 'lesson',
                    title: 'Exploring Turns and Rotations',
                    ageRange: '8-10',
                    content: 'Understand whole, half, quarter, and three-quarter turns using physical movement and diagrams.'
                },
                {
                    id: 'quiz-turns-rotations',
                    type: 'quiz',
                    title: 'Turns and Rotations Quiz',
                    ageRange: '8-10'
                },
                {
                    id: 'game-rotation-challenge',
                    type: 'game',
                    title: 'Rotation Challenge – Match the Turn',
                    ageRange: '8-10'
                },
                {
                    id: 'lesson-clockwise-anticlockwise',
                    type: 'lesson',
                    title: 'Clockwise and Anticlockwise Directions',
                    ageRange: '8-10',
                    content: 'Teach the difference between clockwise and anticlockwise turns.'
                },
                {
                    id: 'quiz-clockwise-anticlockwise',
                    type: 'quiz',
                    title: 'Identify Clockwise and Anticlockwise Quiz',
                    ageRange: '8-10'
                },
                {
                    id: 'game-direction-race',
                    type: 'game',
                    title: 'Direction Race Game',
                    ageRange: '8-10'
                }
            ]
        },
        {
            id: 'positional-challenge',
            title: 'Position & Direction Mastery Challenge',
            activities: [
                {
                    id: 'challenge-position-direction-mastery',
                    type: 'challenge',
                    title: 'Position & Direction Mastery Badge',
                    ageRange: '9-11',
                    content: 'Complete all activities on position, directions, turns, and rotations to unlock the badge.'
                },
                {
                    id: 'reward-position-direction-badge',
                    type: 'reward',
                    title: 'Unlock Position & Direction Mastery Badge',
                    ageRange: '9-11'
                }
            ]
        }
    ]
},
{
    id: 'statistics',
    title: 'Statistics',
    subtopics: [
        {
            id: 'data-collection',
            title: 'Understanding Data Collection',
            activities: [
                {
                    id: 'lesson-data-collection-basics',
                    type: 'lesson',
                    title: 'Introduction to Data Collection',
                    ageRange: '7-9',
                    content: 'Learn how to collect data using objects and tally marks.'
                },
                {
                    id: 'quiz-data-collection',
                    type: 'quiz',
                    title: 'Data Collection Quiz',
                    ageRange: '7-9'
                },
                {
                    id: 'game-data-collection-hunt',
                    type: 'game',
                    title: 'Data Collection Hunt',
                    ageRange: '7-9'
                }
            ]
        },
        {
            id: 'data-representation',
            title: 'Representing Data',
            activities: [
                {
                    id: 'lesson-pictograms',
                    type: 'lesson',
                    title: 'Pictograms and Symbols',
                    ageRange: '8-10',
                    content: 'Learn how to represent data using pictograms and simple symbols.'
                },
                {
                    id: 'quiz-pictograms',
                    type: 'quiz',
                    title: 'Pictogram Interpretation Quiz',
                    ageRange: '8-10'
                },
                {
                    id: 'game-pictogram-challenge',
                    type: 'game',
                    title: 'Pictogram Matching Game',
                    ageRange: '8-10'
                },
                {
                    id: 'lesson-bar-charts',
                    type: 'lesson',
                    title: 'Bar Charts and Graphs',
                    ageRange: '8-10',
                    content: 'Introduction to bar charts, with examples of how to draw and interpret them.'
                },
                {
                    id: 'quiz-bar-charts',
                    type: 'quiz',
                    title: 'Bar Chart Reading Quiz',
                    ageRange: '8-10'
                },
                {
                    id: 'game-bar-chart-builder',
                    type: 'game',
                    title: 'Bar Chart Builder',
                    ageRange: '8-10'
                }
            ]
        },
        {
            id: 'data-interpretation',
            title: 'Interpreting Data',
            activities: [
                {
                    id: 'lesson-data-interpretation-basics',
                    type: 'lesson',
                    title: 'Introduction to Data Interpretation',
                    ageRange: '9-11',
                    content: 'Learn how to interpret data from different types of charts and tables.'
                },
                {
                    id: 'quiz-data-interpretation',
                    type: 'quiz',
                    title: 'Data Interpretation Quiz',
                    ageRange: '9-11'
                },
                {
                    id: 'game-data-interpretation-mystery',
                    type: 'game',
                    title: 'Data Detective Mystery Game',
                    ageRange: '9-11'
                }
            ]
        },
        {
            id: 'statistics-challenge',
            title: 'Statistics Mastery Challenge',
            activities: [
                {
                    id: 'challenge-statistics-mastery',
                    type: 'challenge',
                    title: 'Statistics Mastery Badge',
                    ageRange: '9-11',
                    content: 'Complete all lessons, quizzes, and games to unlock the Statistics Mastery Badge.'
                },
                {
                    id: 'reward-statistics-badge',
                    type: 'reward',
                    title: 'Unlock Statistics Mastery Badge',
                    ageRange: '9-11'
                }
              ]
            }
          ]
        }
      ]
    },
  'key-stage-3': {
    title: 'Key Stage 3 (Ages 11-14)',
    topics: [
      {
        id: 'algebra',
        title: 'Algebra and Equations',
        subtopics: [
          {
            id: 'intro-algebra',
            title: 'Introduction to Algebra',
            lessons: [
              { id: 'simplifying-equations', title: 'Simplifying Equations', ageRange: '11-12' },
              { id: 'linear-equations', title: 'Solving Linear Equations', ageRange: '12-13' }
            ]
          }
        ]
      }
    ]
  },
  'key-stage-4': {
    title: 'Key Stage 4 (Ages 14-16)',
    topics: [
      {
        id: 'advanced-mathematics',
        title: 'Advanced Mathematics',
        subtopics: [
          {
            id: 'trigonometry',
            title: 'Trigonometry Basics',
            lessons: [
              { id: 'sin-cos-tan', title: 'Understanding Sine, Cosine, and Tangent', ageRange: '14-15' },
              { id: 'trig-identities', title: 'Trigonometric Identities', ageRange: '15-16' }
            ]
          }
        ]
      }
    ]
  }
} as const;

// Type definitions for curriculum structure
export type KeyStage = keyof typeof mathematicsCurriculum;
export type Topic = typeof mathematicsCurriculum[KeyStage]['topics'][number];
export type Subtopic = Topic['subtopics'][number];
export type Lesson = Subtopic['lessons'][number];
export type Activity = { type: 'lesson' | 'quiz' | 'game' | 'challenge' | 'reward'; title: string };