import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';
import { enableAuthPersistence } from '../services/auth/persistence';
import { ENV } from './env';

// Initialize Firebase with required config
const firebaseConfig = {
  apiKey: ENV.FIREBASE_CONFIG.API_KEY,
  authDomain: ENV.FIREBASE_CONFIG.AUTH_DOMAIN,
  projectId: ENV.FIREBASE_CONFIG.PROJECT_ID,
  appId: ENV.FIREBASE_CONFIG.APP_ID
};

// Initialize Firebase
export const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);

// Enable persistence
enableAuthPersistence();

// Export isInitialized flag for testing
export const isFirebaseInitialized = true;