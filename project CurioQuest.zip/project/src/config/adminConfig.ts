import { initializeApp, cert } from 'firebase-admin/app';
import { getAuth } from 'firebase-admin/auth';
import { getFirestore } from 'firebase-admin/firestore';

const isDev = import.meta.env.DEV;

// Development configuration
const DEV_ADMIN_CONFIG = {
  projectId: 'demo-project',
  privateKey: 'demo-private-key',
  clientEmail: 'demo@project.iam.gserviceaccount.com'
};

// Production configuration from environment variables
const PROD_ADMIN_CONFIG = {
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID,
  privateKey: import.meta.env.VITE_FIREBASE_ADMIN_PRIVATE_KEY?.replace(/\\n/g, '\n'),
  clientEmail: import.meta.env.VITE_FIREBASE_ADMIN_CLIENT_EMAIL
};

const config = isDev ? DEV_ADMIN_CONFIG : PROD_ADMIN_CONFIG;

// Initialize admin app
const adminApp = initializeApp({
  credential: cert({
    projectId: config.projectId,
    privateKey: config.privateKey,
    clientEmail: config.clientEmail
  })
});

export const adminAuth = getAuth(adminApp);
export const adminDb = getFirestore(adminApp);