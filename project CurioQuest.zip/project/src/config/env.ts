// Environment configuration with strict validation
export const ENV = {
  FIREBASE_CONFIG: {
    API_KEY: import.meta.env.VITE_FIREBASE_API_KEY || 'demo-api-key',
    AUTH_DOMAIN: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN || 'demo-auth-domain',
    PROJECT_ID: import.meta.env.VITE_FIREBASE_PROJECT_ID || 'demo-project-id',
    APP_ID: import.meta.env.VITE_FIREBASE_APP_ID || 'demo-app-id'
  },
  ADMIN: {
    EMAIL: import.meta.env.VITE_ADMIN_EMAIL || 'admin@curioquest.com',
    PASSWORD: import.meta.env.VITE_ADMIN_PASSWORD || 'admin123'
  }
} as const;

// Validate required environment variables in production only
function validateEnv() {
  if (import.meta.env.PROD) {
    const required = {
      'VITE_FIREBASE_API_KEY': ENV.FIREBASE_CONFIG.API_KEY,
      'VITE_FIREBASE_AUTH_DOMAIN': ENV.FIREBASE_CONFIG.AUTH_DOMAIN,
      'VITE_FIREBASE_PROJECT_ID': ENV.FIREBASE_CONFIG.PROJECT_ID,
      'VITE_FIREBASE_APP_ID': ENV.FIREBASE_CONFIG.APP_ID,
      'VITE_ADMIN_EMAIL': ENV.ADMIN.EMAIL,
      'VITE_ADMIN_PASSWORD': ENV.ADMIN.PASSWORD
    };

    const missing = Object.entries(required)
      .filter(([_, value]) => !value)
      .map(([key]) => key);

    if (missing.length > 0) {
      throw new Error(`Missing required environment variables: ${missing.join(', ')}`);
    }
  }
}

// Validate environment variables
validateEnv();