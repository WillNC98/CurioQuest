import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { Home } from './pages/Home';
import { WelcomeHero } from './pages/WelcomeHero/WelcomeHero';
import { HomeworkWizard } from './pages/HomeworkWizard/HomeworkWizard';
import { SubjectsPage } from './pages/Quests/SubjectsPage';
import { QuestsPage } from './pages/Quests/QuestsPage';
import { ErrorBoundary } from './utils/errorBoundary';

function App() {
  return (
    <ErrorBoundary>
      <Router>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/welcome-hero" element={<WelcomeHero />} />
          <Route path="/homework" element={<HomeworkWizard />} />
          <Route path="/quests" element={<SubjectsPage />} />
          <Route path="/quests/:subject" element={<QuestsPage />} />
        </Routes>
      </Router>
    </ErrorBoundary>
  );
}

export default App;