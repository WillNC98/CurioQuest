import { useEffect } from 'react';
import { useAuth } from './useAuth';
import { getUserRole } from '../../../services/auth/roles';

export function useAuthRedirect() {
  const { user } = useAuth();

  useEffect(() => {
    async function handleRedirect() {
      if (user) {
        const role = await getUserRole(user);
        const redirectPath = role === 'admin' ? '/admin' : '/dashboard';
        window.location.href = redirectPath;
      }
    }

    handleRedirect();
  }, [user]);
}