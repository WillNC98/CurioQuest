import { useState, useEffect } from 'react';
import { networkStatus } from '../../../services/network/networkStatus';
import { getOfflineUserData } from '../../../services/auth/offlineAuth';

export function useAuthState() {
  const [isOnline, setIsOnline] = useState(networkStatus.isOnline());
  const [offlineUser, setOfflineUser] = useState(getOfflineUserData());

  useEffect(() => {
    return networkStatus.subscribe((online) => {
      setIsOnline(online);
      if (!online) {
        setOfflineUser(getOfflineUserData());
      }
    });
  }, []);

  return {
    isOnline,
    offlineUser
  };
}