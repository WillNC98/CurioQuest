import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { autoLoginAdmin } from '../../../services/auth/adminAuth';

export function useAdminAuth() {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const navigate = useNavigate();

  useEffect(() => {
    let mounted = true;

    async function performAutoLogin() {
      try {
        const adminData = await autoLoginAdmin();
        if (mounted && adminData) {
          navigate('/welcome-hero');
        }
      } catch (err) {
        if (mounted) {
          const message = err instanceof Error ? err.message : 'Unable to auto-login. Please try again later.';
          setError(message);
        }
      } finally {
        if (mounted) {
          setLoading(false);
        }
      }
    }

    performAutoLogin();

    return () => {
      mounted = false;
    };
  }, [navigate]);

  return { loading, error };
}