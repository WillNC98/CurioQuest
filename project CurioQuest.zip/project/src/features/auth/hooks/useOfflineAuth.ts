import { useState, useCallback } from 'react';
import { validateOfflineAdmin, storeAdminCredentials } from '../../../services/auth/offlineAuth';
import { networkStatus } from '../../../services/network/networkStatus';

export function useOfflineAuth() {
  const [error, setError] = useState<string | null>(null);

  const login = useCallback(async (email: string, password: string) => {
    try {
      if (!networkStatus.isOnline()) {
        const offlineCredentials = validateOfflineAdmin(email, password);
        if (offlineCredentials) {
          storeAdminCredentials();
          return offlineCredentials.userData;
        }
        throw new Error('Invalid credentials for offline login');
      }
      throw new Error('Online login not implemented in offline auth');
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Login failed';
      setError(message);
      throw err;
    }
  }, []);

  return { login, error };
}