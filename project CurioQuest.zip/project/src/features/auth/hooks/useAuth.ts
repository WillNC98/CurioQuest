import { useState, useCallback } from 'react';

// Simplified mock auth hook without Firebase
export function useAuth() {
  const [user] = useState({ id: 'mock-user', email: 'user@example.com' });
  
  const login = useCallback(async () => {
    window.location.href = '/welcome-hero';
  }, []);

  const logout = useCallback(async () => {
    window.location.href = '/';
  }, []);

  return {
    user,
    login,
    logout,
    loading: false,
    error: null
  };
}