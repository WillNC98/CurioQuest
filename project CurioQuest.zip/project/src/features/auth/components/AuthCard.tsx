import React from 'react';

interface AuthCardProps {
  children: React.ReactNode;
  title: string;
}

export function AuthCard({ children, title }: AuthCardProps) {
  return (
    <div className="min-h-screen bg-gradient-to-b from-white to-neutral-50 flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-md w-full space-y-8 bg-white p-8 rounded-2xl shadow-xl">
        <div className="text-center">
          <h2 className="text-3xl font-display font-bold text-neutral-800">{title}</h2>
        </div>
        {children}
      </div>
    </div>
  );
}