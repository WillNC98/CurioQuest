import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { AuthCard } from './AuthCard';
import { AuthInput } from './AuthInput';
import { Button } from '../../../components/common/Button';
import { useAuth } from '../hooks/useAuth';

export function ForgotPasswordForm() {
  const navigate = useNavigate();
  const { resetPassword } = useAuth();
  const [email, setEmail] = useState('');
  const [status, setStatus] = useState<'idle' | 'loading' | 'success' | 'error'>('idle');
  const [error, setError] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setStatus('loading');
    setError('');

    try {
      await resetPassword(email);
      setStatus('success');
    } catch (err) {
      setStatus('error');
      setError(err instanceof Error ? err.message : 'Failed to send reset email');
    }
  };

  return (
    <AuthCard title="Reset Password">
      <form onSubmit={handleSubmit} className="space-y-6">
        {status === 'success' ? (
          <div className="text-sm text-green-600 bg-green-50 p-3 rounded-lg">
            Check your email for password reset instructions.
          </div>
        ) : (
          <>
            <p className="text-sm text-neutral-600">
              Enter your email address and we'll send you instructions to reset your password.
            </p>

            <AuthInput
              id="email"
              label="Email Address"
              type="email"
              value={email}
              onChange={e => setEmail(e.target.value)}
              error={error}
              required
            />

            <Button
              type="submit"
              className="w-full"
              disabled={status === 'loading'}
            >
              {status === 'loading' ? 'Sending...' : 'Send Reset Link'}
            </Button>
          </>
        )}

        <p className="text-center text-sm text-neutral-600">
          Remember your password?{' '}
          <button
            type="button"
            onClick={() => navigate('/login')}
            className="text-primary hover:underline"
          >
            Sign in
          </button>
        </p>
      </form>
    </AuthCard>
  );
}