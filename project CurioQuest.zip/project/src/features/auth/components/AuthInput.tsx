import React from 'react';

interface AuthInputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label: string;
  error?: string;
}

export function AuthInput({ label, error, ...props }: AuthInputProps) {
  return (
    <div className="space-y-1">
      <label className="block text-sm font-medium text-neutral-700" htmlFor={props.id}>
        {label}
      </label>
      <input
        className={`w-full px-4 py-2 rounded-xl border ${
          error ? 'border-red-300' : 'border-neutral-300'
        } focus:ring-2 focus:ring-primary/20 focus:border-primary transition-colors`}
        {...props}
      />
      {error && <p className="text-sm text-red-500">{error}</p>}
    </div>
  );
}