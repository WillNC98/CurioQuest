import React, { useState } from 'react';
import { AuthInput } from './AuthInput';
import { Button } from '../../../components/common/Button';
import { useAuth } from '../hooks/useAuth';
import { validatePassword, validateEmail } from '../utils/validation';

interface RegisterFormProps {
  onSuccess?: () => void;
  onLogin?: () => void;
}

export function RegisterForm({ onSuccess, onLogin }: RegisterFormProps) {
  const { register } = useAuth();
  const [formData, setFormData] = useState({
    email: '',
    password: '',
    fullName: '',
    role: 'child' as 'parent' | 'child'
  });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrors({});

    // Validate inputs
    const newErrors: Record<string, string> = {};
    if (!validateEmail(formData.email)) {
      newErrors.email = 'Please enter a valid email address';
    }
    if (!validatePassword(formData.password)) {
      newErrors.password = 'Password must be at least 8 characters with a number and special character';
    }
    if (!formData.fullName) {
      newErrors.fullName = 'Full name is required';
    }

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }

    setIsLoading(true);
    try {
      await register(formData);
      onSuccess?.();
    } catch (error) {
      setErrors({
        submit: error instanceof Error ? error.message : 'Registration failed'
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h2 className="text-2xl font-display font-bold text-neutral-800">Join CurioQuest</h2>
        <p className="mt-2 text-sm text-neutral-600">Start your learning adventure today</p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        <AuthInput
          id="fullName"
          label="Full Name"
          type="text"
          value={formData.fullName}
          onChange={e => setFormData(prev => ({ ...prev, fullName: e.target.value }))}
          error={errors.fullName}
          required
        />

        <AuthInput
          id="email"
          label="Email Address"
          type="email"
          value={formData.email}
          onChange={e => setFormData(prev => ({ ...prev, email: e.target.value }))}
          error={errors.email}
          required
        />

        <AuthInput
          id="password"
          label="Password"
          type="password"
          value={formData.password}
          onChange={e => setFormData(prev => ({ ...prev, password: e.target.value }))}
          error={errors.password}
          required
        />

        <div className="space-y-1">
          <label className="block text-sm font-medium text-neutral-700">I am a:</label>
          <div className="flex gap-4">
            {['child', 'parent'].map(role => (
              <label key={role} className="flex items-center">
                <input
                  type="radio"
                  name="role"
                  value={role}
                  checked={formData.role === role}
                  onChange={e => setFormData(prev => ({ ...prev, role: e.target.value as 'parent' | 'child' }))}
                  className="mr-2"
                />
                <span className="capitalize">{role}</span>
              </label>
            ))}
          </div>
        </div>

        {errors.submit && (
          <div className="text-sm text-red-500 bg-red-50 p-3 rounded-lg">
            {errors.submit}
          </div>
        )}

        <Button
          type="submit"
          className="w-full"
          disabled={isLoading}
        >
          {isLoading ? 'Creating Account...' : 'Create Account'}
        </Button>
      </form>

      <p className="text-center text-sm text-neutral-600">
        Already have an account?{' '}
        <button
          type="button"
          onClick={onLogin}
          className="text-primary hover:underline"
        >
          Sign in
        </button>
      </p>
    </div>
  );
}