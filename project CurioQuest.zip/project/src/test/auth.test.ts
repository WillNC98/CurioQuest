import { describe, it, expect } from 'vitest';
import { signIn, signUp, signOut } from '../services/auth/authService';
import { mockUser } from '../services/auth/mockAuth';

describe('Auth Service', () => {
  it('should sign in user in development mode', async () => {
    const user = await signIn('test@example.com', 'password');
    expect(user).toEqual(mockUser);
  });

  it('should sign up user in development mode', async () => {
    const user = await signUp('test@example.com', 'password');
    expect(user).toEqual(mockUser);
  });

  it('should sign out in development mode', async () => {
    await expect(signOut()).resolves.not.toThrow();
  });
});