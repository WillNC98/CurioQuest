import { describe, it, expect } from 'vitest';
import { isFirebaseInitialized } from '../config/firebase';

describe('Firebase Configuration', () => {
  it('should initialize Firebase in development mode', () => {
    expect(isFirebaseInitialized()).toBe(true);
  });
});