// Add to existing types
export interface UserProgress {
  userId: string;
  experiencePoints: number;
  level: number;
  comprehensionLevels: Record<string, ComprehensionLevel>;
  completedActivities: string[];
  unlockedRewards: string[];
}

export interface ActivityCompletion {
  experiencePoints: number;
  rewards?: Reward[];
}

export interface ProgressRequirement {
  requiredLevel: number;
  requiredExperiencePoints: number;
  requiredActivities?: string[];
}

// Update LearningLevel interface
export interface LearningLevel {
  id: string;
  level: ComprehensionLevel;
  activities: Activity[];
  isLocked: boolean;
  requirement: ProgressRequirement;
  rewards: Reward[];
}