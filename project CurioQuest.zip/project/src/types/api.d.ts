// API Response types
export interface ApiResponse<T> {
  data: T;
  status: number;
  message?: string;
}

// User types
export interface User {
  id: string;
  email: string;
  name: string;
  progress?: number;
}

// Course types
export interface Course {
  id: string;
  title: string;
  description: string;
  progress: number;
  lessons: Lesson[];
}

export interface Lesson {
  id: string;
  title: string;
  completed: boolean;
}