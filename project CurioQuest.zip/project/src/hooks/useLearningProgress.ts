import { useState, useEffect } from 'react';
import { useAuth } from './useAuth';
import {
  getUserProgress,
  completeActivity,
  checkLevelUnlock
} from '../services/learning/progressService';
import { getExperienceProgress } from '../services/learning/experienceService';
import { Activity, UserProgress, ActivityCompletion } from '../types/learning';

export function useLearningProgress() {
  const { user } = useAuth();
  const [progress, setProgress] = useState<UserProgress | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<Error | null>(null);

  useEffect(() => {
    async function fetchProgress() {
      if (!user) return;
      
      try {
        const userProgress = await getUserProgress(user.uid);
        setProgress(userProgress);
      } catch (err) {
        setError(err instanceof Error ? err : new Error('Failed to fetch progress'));
      } finally {
        setLoading(false);
      }
    }

    fetchProgress();
  }, [user]);

  const handleActivityCompletion = async (
    activity: Activity,
    performance: number = 1
  ): Promise<ActivityCompletion> => {
    if (!user || !progress) {
      throw new Error('User not authenticated');
    }
    
    try {
      const result = await completeActivity(user.uid, activity, performance);
      
      // Update local progress state
      setProgress(prev => prev ? {
        ...prev,
        experiencePoints: prev.experiencePoints + result.experiencePoints,
        completedActivities: [...prev.completedActivities, activity.id]
      } : null);
      
      return result;
    } catch (err) {
      setError(err instanceof Error ? err : new Error('Failed to complete activity'));
      throw err;
    }
  };

  const getLevelProgress = () => {
    if (!progress) return 0;
    return getExperienceProgress(progress.experiencePoints);
  };

  return {
    progress,
    loading,
    error,
    handleActivityCompletion,
    getLevelProgress,
    experienceProgress: getLevelProgress()
  };
}