import { useState, useEffect } from 'react';

export function useProgress(initialProgress: number = 0) {
  const [progress, setProgress] = useState(initialProgress);

  useEffect(() => {
    // Clean way to handle progress updates
    const interval = setInterval(() => {
      setProgress(prev => Math.min(prev + 1, 100));
    }, 1000);

    // Proper cleanup
    return () => clearInterval(interval);
  }, []);

  return progress;
}