import { useState, useEffect } from 'react';
import { useAuthContext } from '../services/auth/authProvider';
import { getUserCourses } from '../services/db/courseService';
import { Course } from '../types/api';
import { useAsync } from './useAsync';

export function useCourses() {
  const { user } = useAuthContext();
  const [courses, setCourses] = useState<Course[]>([]);
  const { loading, error, execute } = useAsync<Course[]>();

  useEffect(() => {
    if (user) {
      execute(getUserCourses(user.id))
        .then(setCourses)
        .catch(console.error);
    }
  }, [user, execute]);

  return { courses, loading, error };
}