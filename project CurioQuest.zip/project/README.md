# CurioQuest

An interactive learning platform that adapts to your interests and progress.

## Project Structure

```
src/
├── assets/           # Static assets and branding elements
│   ├── fonts/       # Custom fonts
│   ├── icons/       # SVG icons
│   └── images/      # Images and illustrations
├── components/       # Reusable UI components
│   ├── common/      # Shared components (buttons, inputs, etc.)
│   └── layout/      # Layout components (header, footer, etc.)
├── pages/           # Page components
├── styles/          # Global styles and theme configuration
├── utils/           # Utility functions and helpers
└── services/        # API and external service integrations
```

## Getting Started

1. Clone the repository
2. Install dependencies: `npm install`
3. Start development server: `npm run dev`

## Development Guidelines

- Follow component naming convention: PascalCase (e.g., ButtonComponent.tsx)
- Keep components small and focused
- Write meaningful commit messages: `<type>(<scope>): <description>`
- Create feature branches for new development

## Branch Strategy

- `main`: Production-ready code
- `feature/ui-components`: UI component development
- `feature/api-integration`: API integration
- `feature/authentication`: Authentication logic